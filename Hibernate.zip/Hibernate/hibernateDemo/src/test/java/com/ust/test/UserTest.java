package com.ust.test;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.ust.dto.util.HibernateUtil;
import com.ust.dto.util.UserDetails;

public class UserTest {
	
	public static void main(String[] args) {
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction transaction = null;

		try {
			transaction = session.beginTransaction();

			// Create a new entity object
			UserDetails u1 = new UserDetails();
			u1.setUserId(1);
			u1.setUsername("Dijo J");

			// Save the entity
			session.save(u1);

			transaction.commit();
		} catch (Exception e) {
			if (transaction != null) {
				transaction.rollback();
			}
			e.printStackTrace();
		} finally {
			session.close();
		}
	}

}
