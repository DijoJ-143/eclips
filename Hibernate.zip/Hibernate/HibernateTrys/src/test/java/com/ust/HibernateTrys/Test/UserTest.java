package com.ust.HibernateTrys.Test;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.ust.HibernateTrys.HibernateUtil;
import com.ust.HibernateTrys.Dto.UserDetail;

public class UserTest {

	public static void main(String[] args) {

		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction transaction = null;

		try {
			transaction = session.beginTransaction();

			// Create a new entity object
			UserDetail u1 = new UserDetail();
			u1.setUserId(1);
			u1.setUsername("Dijo J");

			// Save the entity
			session.save(u1);

			transaction.commit();
		} catch (Exception e) {
			if (transaction != null) {
				transaction.rollback();
			}
			e.printStackTrace();
		} finally {
			session.close();
		}
	}
}
