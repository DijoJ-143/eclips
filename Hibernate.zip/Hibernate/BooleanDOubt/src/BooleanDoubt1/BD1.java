package BooleanDoubt1;

public class BD1 {

	public static void main(String[] args) {
//		Scanner sc = new Scanner(System.in);
//		boolean value = false;
//		
//		String val = sc.next();
//		
//		value =val.length()==1 ;
//		
//		System.out.println(value);

		String s = new String("java1211;12222we");
		System.out.println((int) s.charAt(1));
		System.out.println(s.codePointAt(1));

		System.out.println(s.contains("."));
		System.out.println(s.getBytes());
		System.out.println(s.intern());

		System.out.println(s.indexOf("java"));

		for (int i = 0; i < s.length(); i++) {
			if (Character.isLetter(s.charAt(i)))
				System.out.println(s.charAt(i) + " : is a character  ");
			else if (Character.isDigit(s.charAt(i)))
				System.out.println(s.charAt(i) + " : is a digit  ");
			else
				System.out.println(s.charAt(i) + " : is a non-alphabet and non-digit characters.");
}

		
		
//		StringBuffer
	byte b = (byte)140;
	System.out.println(b);
	
	System.out.println(20+(~10+1));
	System.out.println(10>>1);
	System.out.println(1/10);
	}

}
