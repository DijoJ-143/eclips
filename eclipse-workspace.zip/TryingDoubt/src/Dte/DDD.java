package Dte;

import java.util.Date;

public class DDD {
	
	public static void main(String[] args) {
		System.out.println(new Date());
	}

}
