package jBean.TaskJBean.FewJavaBeanClasses;

import java.io.Serializable;

public class Student implements Serializable {

	// properties
	private int id;
	private String name;
	private long scrore;

	// public no argument constructor
	public Student() {
	}

	// serialVersionUID
	private static final long serialVersionUID = 1L;

	// getter and setter
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public long getScrore() {
		return scrore;
	}

	public void setScrore(long scrore) {
		this.scrore = scrore;
	}

}
