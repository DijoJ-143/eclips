package jBean.TaskJBean.FewJavaBeanClasses;

import java.io.Serializable;

public class Order implements Serializable {
    private static final long serialVersionUID = 3L; // Unique ID for Order class

    //properties
    private int orderId;
    private User user;
    private Product product;

    public Order() {}

    //getetr and setter
    public int getOrderId() {
        return orderId;
    }

    public void setOrderId(int orderId) {
        this.orderId = orderId;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public Product getProduct() {
        return product;
    }

    public void setProduct(Product product) {
        this.product = product;
    }
}
