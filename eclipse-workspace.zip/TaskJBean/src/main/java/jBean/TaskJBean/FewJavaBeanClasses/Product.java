package jBean.TaskJBean.FewJavaBeanClasses;

import java.io.Serializable;

public class Product implements Serializable {
	private static final long serialVersionUID = 2L; // Unique ID for Product class

	// properties
	private String productName;
	private double price;

	//constructor
	public Product() {
	}

	// getter and setter
	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}
}
