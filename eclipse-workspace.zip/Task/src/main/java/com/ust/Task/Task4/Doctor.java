package com.ust.Task.Task4;

public class Doctor {
	// id
	private int did;
	// name
	private String dname;
	// contactinfo
	private String dcontactInfo;
	// specialty
	private String specialty;

	// constructor
	public Doctor(int did, String dname, String dcontactInfo, String specialty) {
		super();
		this.did = did;
		this.dname = dname;
		this.dcontactInfo = dcontactInfo;
		this.specialty = specialty;
	}

	// getter and setter
	public int getDid() {
		return did;
	}

	public void setDid(int did) {
		this.did = did;
	}

	public String getDname() {
		return dname;
	}

	public void setDname(String dname) {
		this.dname = dname;
	}

	public String getDcontactInfo() {
		return dcontactInfo;
	}

	public void setDcontactInfo(String dcontactInfo) {
		this.dcontactInfo = dcontactInfo;
	}

	public String getSpecialty() {
		return specialty;
	}

	public void setSpecialty(String specialty) {
		this.specialty = specialty;
	}

	@Override
	public String toString() {
		return "Doctor info[ " + getDid() + " || " + getDname() + " || " + getDcontactInfo() + " || " + getSpecialty() + " ]";
	}

}
