package com.ust.Task.Task5Important;

class SharedResource {
	private boolean available = false;

	public synchronized void produce() {
		while (available) {
			try {
				wait(); // Wait until the resource is consumed
			} catch (InterruptedException e) {
				Thread.currentThread().interrupt();
			}
		}
		// Produce the resource
		System.out.println("Produced resource");
		available = true;
		notify(); // Notify the consumer that the resource is available
	}

	public synchronized void consume() {
		while (!available) {
			try {
				wait(); // Wait until the resource is produced
			} catch (InterruptedException e) {
				Thread.currentThread().interrupt();
			}
		}
		// Consume the resource
		System.out.println("Consumed resource");
		available = false;
		notify(); // Notify the producer that the resource is consumed
	}
}

public class ThreadWorking {
	public static void main(String[] args) {
		SharedResource resource = new SharedResource();

		Thread producer = new Thread(resource::produce);
		Thread consumer = new Thread(resource::consume);

		producer.start();
		consumer.start();

	}
}
