package com.ust.Task.Task1;

import java.util.Scanner;

public class CompareString {
	// Comparing the string
	public static void main(String[] args) {
		// input the value
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the string1");
		String str1 = sc.nextLine();
		System.out.println("Enter the string2");
		String str2 = sc.nextLine();

		// printing the output
		if (comparingTheStrings(str1, str2))
			System.out.println('"' + str1 + '"' + " is equal to " + '"' + str2 + '"');
		else
			System.err.println('"' + str1 + '"' + " is not equal to " + '"' + str2 + '"');

	}

	// parameterized method for comparing the two given strings
	public static boolean comparingTheStrings(String s1, String s2) {
		return s1.equalsIgnoreCase(s2);
	}

}

/*
 * Enter the string1
ffff
Enter the string2
hhhh
"ffff" is not equal to "hhhh"

 */
