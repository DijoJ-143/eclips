package com.ust.Task.Task1;

import java.util.Scanner;

//Spliting the string using delimiter
public class SplitString {
	public static void main(String[] args) {
		// inputing strings
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the string");
		String str = sc.nextLine();

		System.out.println("Enter the delimiter");
		String delimiter = sc.next();

		// output
		String[] result = splitTheString(str, delimiter);
		// printing the result
		for (String s : result) {
			System.out.println(s);
		}

	}

	public static String[] splitTheString(String str, String delimiter) {
		return str.split(delimiter);
	}

}

/*
 * cosole
 *  Enter the string
 *  dijo j is a good boy
 *  Enter the delimiter o 
 *  dij j is a
 * g
 * 
 * d b y
 */
