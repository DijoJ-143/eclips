package com.ust.Task.File;

import java.io.File;
import java.io.IOException;

public class Filemanager {
	File file = null;

	public Filemanager() {
		super();

	}

	// File the parent class for the creation of files
	public void createFile(String path) {

		try {
			file = new File(path);
			// returns boolean value by createNewFile method true for the creation and false
			// if the file already exist
			if (file.createNewFile())
				System.out.println("Created file ");
			else
				System.out.println("File Already Exist");
		} catch (IOException e) {
			// TODO: handle exception
			System.err.println("issue with the path");
		}
	}

	// file details
	public void getFullFileData(String path) {
		try {
			file = new File(path);
			if (file.exists()) {
				System.out.println("File name :" + file.getName());
				System.out.println("File Location :" + file.getAbsolutePath());
				System.out.println("Size : " + file.length());
				System.out.println("__________________________________________");
				System.out.println("can read : " + file.canRead());
				System.out.println("can write : " + file.canWrite());
			}
		} catch (Exception e) {
			// TODO: handle exception
		}

	}

}
