package com.ust.Task.Taskgiven.person;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class MainClass {
	public static void main(String[] args) {

		// list of persons
		List<Person> persons = Arrays.asList(new Person("Dijo", "J", 23, "male"),
				new Person("Karthik", "K Nair", 23, "male"), new Person("Raju", "K ", 17, "male"),
				new Person("Ravethi", " Nair", 18, "female"), new Person("Dhanush", "R", 16, "male"),
				new Person("Sanu", "P", 18, "male"), new Person("Devika", "K ", 19, "female"));

		// person whose age is less than 18

		ageLessthan(persons).forEach(System.out::println);
	}

	public static List<Person> ageLessthan(List<Person> p) {

		List<Person> result = p.stream().filter(person -> person.getAge() < 18).collect(Collectors.toList());
		return result;
	}

}
