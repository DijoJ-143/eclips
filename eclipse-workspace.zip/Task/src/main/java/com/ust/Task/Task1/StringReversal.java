package com.ust.Task.Task1;

import java.util.Scanner;

//reversing the givien input
public class StringReversal {
	public static void main(String[] args) {

		// Scanner object for gettingn the input
		Scanner sc = new Scanner(System.in);

		System.out.println("Enter a string");
		String input = sc.next();

		// printing the reversed output
		System.out.println("Reversed String :" + reversedString(input));

	}

	// parameterised method where the input a string and return an reversed string
	public static String reversedString(String input) {

		StringBuffer sb = new StringBuffer(input);
		return sb.reverse().toString();
	}
}

/*
 * output
 * 
 * Enter a string dijoj 
 * Reversed String :jojid
 */
