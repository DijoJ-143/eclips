package com.ust.Task.Task3;

import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class EmailParsing {
	/*
	 * validate an email address using regex.
	 */
	public static void main(String[] args) {
		// creating a list containing emails
		List<String> emails = Arrays.asList("dijoj@gmail.com", "gfadhgfagj@hgsgdfhgaujhdgfjhagjhf", "jhcgjhasgcjhga",
				"user@example.com", "another.user@domain.com", "invalid-email", "user@invalid", "user@example",
				"test@valid.net", "abcde@domain.xyz");

		// rules
		String regrex = "^[a-zA-Z0-9+.\\-*]+@[a-z]+\\.[a-z]{3}$";

		// Pattern
		Pattern p = Pattern.compile(regrex);

		for (String s : emails) {
			// Matcher
			Matcher m = p.matcher(s);

			if (m.find()) {
				System.out.println(m.group());
			}

		}

	}

}
