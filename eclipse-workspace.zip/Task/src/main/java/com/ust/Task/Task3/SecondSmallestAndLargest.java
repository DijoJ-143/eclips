package com.ust.Task.Task3;

import java.util.Arrays;
import java.util.List;

/*
 *  Write a Java program to find the second smallest and largest elements in a list of integers using streams.
 */
public class SecondSmallestAndLargest {
	public static void main(String[] args) {

		// creating a list of integers
		List<Integer> li = Arrays.asList(1, 3, 2, 4, 5, 6);

		// logic for to find second smallest integer
		System.out.println(" Second smallest one is : " + li.stream().distinct().sorted().skip(1).findFirst().get());

		// logic for to find the second largest one

		System.out.println(" second largest one is : "
				+ li.stream().distinct().sorted((a, b) -> Integer.compare(b, a)).skip(1).findFirst().orElseGet(null));

	}

}
/*
 * output Second smallest one is : 2
 *  second largest one is : 5
 */
