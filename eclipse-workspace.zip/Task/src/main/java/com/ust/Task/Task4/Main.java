package com.ust.Task.Task4;

import java.time.LocalDateTime;

public class Main {

	public static void main(String[] args) {

		// local date time
		LocalDateTime dateTime = LocalDateTime.now();
		// Instantiate a HospitalManager object
		HospitalManager hm = new HospitalManager();

		// Patient
		Patient p1 = new Patient(1, "Dino", "123-234-121");
		Patient p2 = new Patient(2, "Einoh", "143-234-121");
		Patient p3 = new Patient(3, "Tinosmu", "123-238-127");

		// Doctors
		Doctor d1 = new Doctor(1, "Alice", "Cardiologist", "111-222-3333");
		Doctor d2 = new Doctor(2, "Bob", "Neurologist", "444-555-6666");

		// operations
		hm.addPatient(p1);
		hm.addPatient(p2);
		hm.addPatient(p3);

		hm.addDoctor(d1);
		hm.addDoctor(d2);

		hm.scheduleAppointment(1, 1, 1, dateTime.plusDays(1));

		hm.listAllAppoinment();
		hm.listAllDoctors();
		hm.listAllPatient();

	}

}
