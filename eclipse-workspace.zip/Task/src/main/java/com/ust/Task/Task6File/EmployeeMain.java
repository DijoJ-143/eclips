package com.ust.Task.Task6File;

import java.util.logging.ErrorManager;

public class EmployeeMain {
	public static void main(String[] args) {

		// instance of employee manager
		EmployeeManager em = new EmployeeManager();

		// creating employees
		Employee e1 = new Employee(1, 23, "Karthik", 23900.0);
		Employee e2 = new Employee(2, 24, "gogul", 27900.0);
		Employee e3 = new Employee(3, 28, "Priyanka", 139000.0);
		Employee e4 = new Employee(4, 23, "Amith S", 23000.0);
		Employee e5 = new Employee(5, 23, "Alin", 23000.0);

		// adding employee
		em.addEmployee(e1);
		em.addEmployee(e2);
		em.addEmployee(e3);
		em.addEmployee(e4);
		em.addEmployee(e5);
		
		//printing the employee details
		em.printEmployeeDataInPath(5, "Alin.txt");
	}

}
