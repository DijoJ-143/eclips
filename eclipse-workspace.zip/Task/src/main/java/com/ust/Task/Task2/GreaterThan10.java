package com.ust.Task.Task2;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.function.Consumer;
import java.util.stream.Collectors;

/*filter a list of integers to include only numbers greater than 10 
 * and then create a new list where each number is multiplied by 2*/
public class GreaterThan10 {
	public static void main(String[] args) {

		// Variables
		int size;
		Scanner sc = new Scanner(System.in);

		// input size
		System.out.println("Enter the size of list");
		size = sc.nextInt();

		// creating a list
		List<Integer> li = new ArrayList<>(size);
		// input numbers

		for (int i = 0; i < size; i++) {
			System.out.println("Enter the num" + i + " : ");
			li.add(sc.nextInt());
		}

		System.out.println(passTheList(li));

	}

	// parameterized method to process the list
	public static List<Integer> passTheList(List<Integer> li) {

		return li.stream().filter(x -> x > 10).map(x -> x * 2).collect(Collectors.toList());

	}

}

/*
 * output 
 * Enter the size of list 
 * 3
 *  Enter the num0 : 1
 *   Enter the num1 : 2 
 *   Enterthe num2 : 22 
 *   [44]
 * 
 */
