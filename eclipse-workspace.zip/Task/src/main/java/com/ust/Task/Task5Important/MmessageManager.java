package com.ust.Task.Task5Important;

import java.util.Vector;

public class MmessageManager {
	// creation of an vector
	private final Vector<Mmessage> messages;

	// constructor
	public MmessageManager() {
		// TODO Auto-generated constructor stub
		messages = new Vector<>();
	}

	// synchronized messsage add method
	public synchronized void addMessage(Mmessage message) {

		messages.add(message);
//		Wakes up a single thread that is waiting on this object'smonitor.
//		If any threads are waiting on this object, one of themis chosen to be awakened. 
//		The choice is arbitrary and occurs atthe discretion of the implementation. 
//		A thread waits on an object'smonitor by calling one of the wait methods. 
		notify();

	}

	// Synchronized method to retrieve a message
	public synchronized Mmessage retrieveMessage() throws InterruptedException {
		while (messages.isEmpty()) {
			wait(); // Wait if the list is empty
		}
		return messages.remove(0);
	}

	// listing all messages
	public synchronized void listAllMessages() throws InterruptedException {

		messages.forEach(System.out::println);
	}

}
