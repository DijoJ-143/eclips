package com.ust.Task.Task5Important;

public class Tmain {
	public static void main(String[] args) {

		// instance of Ttranfer class
		Ttranfer ttranfer = new Ttranfer();
		// instance of TmessageTransfer class
		TmessageTransfer msg1 = new TmessageTransfer("hai", ttranfer);

		// starting the thread
		msg1.start();
	}

}
