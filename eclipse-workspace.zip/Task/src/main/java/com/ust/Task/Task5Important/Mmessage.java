package com.ust.Task.Task5Important;

public class Mmessage {
	// properties
	private int id;
	private String content;

	// constructor
	public Mmessage(int id, String content) {
		super();
		this.id = id;
		this.content = content;
	}

	// gettter and setter
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "message:: [ id::" + this.getId() + " || content:: " + this.getContent() + " ]";
	}
}
