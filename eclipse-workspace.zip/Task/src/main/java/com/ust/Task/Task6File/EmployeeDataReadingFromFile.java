package com.ust.Task.Task6File;

import java.nio.file.Files;
import java.nio.file.Path;

import javax.swing.JFileChooser;

public class EmployeeDataReadingFromFile {

	public void readDataFrom() {

		// Gui based file opening
		JFileChooser jfile = new JFileChooser();
		jfile.showOpenDialog(null);

		// converting it into path or selecting the path of file selected
		Path p = Path.of(jfile.getSelectedFile().getPath());
		try {
			String data = Files.readString(p);
			if (!(data.isEmpty())) {
				System.out.println("FILE CONTENT: \n" + data);
			}

			else {
				System.err.println("invalid file");
			}
		} catch (Exception e) {
			// TODO: handle exception
			System.err.println("unable to process the file");
		}

	}

	public static void main(String[] args) {
		EmployeeDataReadingFromFile edf = new EmployeeDataReadingFromFile();
		edf.readDataFrom();

	}

}
