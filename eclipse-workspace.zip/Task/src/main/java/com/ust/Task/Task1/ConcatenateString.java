package com.ust.Task.Task1;

import java.util.Scanner;

public class ConcatenateString {
	// concatenating two input strings
	public static void main(String[] args) {

		// inputing strings
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the strings1");
		String s1 = sc.next();
		System.out.println("Enter the strings2");
		String s2 = sc.next();

		// output
		System.out.println("concated string : " + concatString(s1, s2));

	}

	// parametrized method for concating the strings
	public static String concatString(String s1, String s2) {

		StringBuffer sb = new StringBuffer(s1);

		return (sb.append(s2)).toString();
	}
}

/*
 * output
 * 
 * Enter the strings1 dijo
 *  Enter the strings2 j 
 *  concated string : dijoj
 */
