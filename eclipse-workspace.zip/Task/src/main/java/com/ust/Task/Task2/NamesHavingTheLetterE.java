package com.ust.Task.Task2;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;
//filter a list of names to include only those that contain the letter "e" and then collect them into a new list

public class NamesHavingTheLetterE {
	public static void main(String[] args) {

		// Variables
		int size;
		Scanner sc = new Scanner(System.in);

		// input size
		System.out.println("Enter the size of list");
		size = sc.nextInt();

		// creating a list
		List<String> li = new ArrayList<>();
		// input names

		for (int i = 0; i < size; i++) {
			System.out.println("Enter the " + i + "st name : ");
			li.add(sc.next());

		}

		// output
		System.out.println(passTheList(li));

	}

	public static List<String> passTheList(List<String> li) {
		// TODO Auto-generated method stub
		return li.stream().filter(x -> x.contains("e")).collect(Collectors.toList());
	}

}


/*outout
 * Enter the size of list
4
Enter the 0st name : 
dijo
Enter the 1st name : 
ebin
Enter the 2st name : 
anyo
Enter the 3st name : 
emul
[ebin, emul]
*/
