package com.ust.Task.Taskgiven;

import java.util.Map;
import java.util.Scanner;
import java.util.stream.Collectors;

public class RepAndCount {

	// main method
	public static void main(String[] args) {

		// Scanner class
		Scanner sc = new Scanner(System.in);

		System.out.println("Enter a String");
		String value = sc.nextLine();

		System.out.println("\n The count of repeating characters are : \n ");
		FindRepandCount(value);
	}

	private static void FindRepandCount(String value) {
		// TODO Auto-generated method stub

		Map<Character, Long> counts = value.chars()
				.mapToObj(c -> (char) c)
				.collect(Collectors.groupingBy(c -> c, Collectors.counting()));

		counts.entrySet().stream().filter(e -> e.getValue() > 1).forEach(System.out::println);

	}

}
