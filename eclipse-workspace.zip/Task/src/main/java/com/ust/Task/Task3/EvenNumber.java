package com.ust.Task.Task3;

import java.util.Arrays;
import java.util.List;

/*
 * Write a Java method that takes in a list of integers and performs the following operations using Java 8 streams:

Filter out the even numbers.
Square each even number.
Compute the sum of the squared numbers.
 */
public class EvenNumber {
	public static void main(String[] args) {
		//creating  an list of integers
		List<Integer> li = Arrays.asList(1,2,3,4,5,6,7,8,9,10);
		
		System.out.println(li.stream().filter(x->x%2==0).map(x->x*x).reduce(0,(a,b)->a+b));
		
		
	}

}
