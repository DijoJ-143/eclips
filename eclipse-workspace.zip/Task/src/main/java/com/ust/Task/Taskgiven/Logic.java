
package com.ust.Task.Taskgiven;

import java.util.Map;
import java.util.stream.Collectors;

public class Logic {
	public static void main(String[] args) {
		
		String value = "ASSDFFF";
		
		//creating an int stream and converting it to char and getting its count
		Map<Character, Long> countOfChar = value.chars()
				.mapToObj(c->(char)c)
				.collect(Collectors.groupingBy(c->c,Collectors.counting()));
		
		System.out.println(countOfChar.entrySet());
				
		
		
		
		
	}

}





