package com.ust.Task.Task3;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Scanner;
/*
 * Write a Java program that displays the current date and time, and then calculates and displays the date and time exactly one week from now.
 */
public class DateAndTime {
	public static void main(String[] args) {
		
		
		//LocalDateTime class intialization
		LocalDateTime today = LocalDateTime.now();
		
		//printing current date 
		System.out.println("TODAY : "+today);
		
		//displaying output for after 1 week
		System.out.println("After one week : "+today.plusWeeks(1));
		
		
	}

}
