package com.ust.Task;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
        
        List<Integer> al =  Arrays.asList();
        System.out.println(al);
       
   Collections.sort(al);
  al.forEach(System.out::println);
        
        
    }
}
