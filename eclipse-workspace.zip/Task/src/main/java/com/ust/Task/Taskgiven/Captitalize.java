package com.ust.Task.Taskgiven;

import java.util.Arrays;
import java.util.stream.Collectors;

public class Captitalize {

	private static String captalizeAtBegining(String words) {
		// TODO Auto-generated method stub

		String[] str = words.split(" ");

		String result = Arrays.stream(str).map(word -> word.substring(0, 1).toUpperCase() + word.substring(1))
				.collect(Collectors.joining(" "));

		return result;

	}

	public static void main(String[] args) {
		String words = "india is my country";
		System.out.println(captalizeAtBegining(words));

	}

}
