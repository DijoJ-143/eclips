package com.ust.Task;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Predicate;

import org.apache.commons.lang3.StringUtils;

public class Count {
	public static void main(String[] args) {
		// input string
		String s = "ASSDFFF";
		int count = 0;
		int count1 = 0;

		// my logic
		// converting to set for eliminating duplicate ones
		Set<Character> s21 = new HashSet<>();

//		s21.forEach(x->System.out.println(x));

		// addding to the set
		for (char c : s.toCharArray()) {
			s21.add(c);
		}
		// converting back to list so as to use the get method
		List<Character> c2 = new ArrayList<>(s21);

		for (int i = 0; i < c2.size(); i++) {
			for (int j = 0; j < s.length(); j++) {
				if (c2.get(i) == s.charAt(j)) {
					count1++;
				}

			}
			System.out.println(c2.get(i) + " count : " + count1);
			count1 = 0;
		}

		System.out.println("-----------------------------------");

		// self learned logic
		// using apache lib
		char[] data = s.toCharArray();
		Map<Character, Integer> map = new HashMap<>();
		for (char c : data) {
			count = StringUtils.countMatches(s, c);
			map.put(c, count);

		}
		// Print the contents of the map
		map.forEach((character, counts) -> {
			System.out.println("Character " + character + " occurred : " + counts + " times");
		});

	}

}
