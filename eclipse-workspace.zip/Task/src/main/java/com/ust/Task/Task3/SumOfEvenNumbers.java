package com.ust.Task.Task3;

import java.util.Arrays;
import java.util.List;
import java.util.function.Predicate;

/*
 * Write a Java method that takes in a list of integers and returns the sum of all even numbers in the list using Java 8 streams.
 */
public class SumOfEvenNumbers {

	static int sum = 0;

	public static void main(String[] args) {
		// intializing a list of integers
		List<Integer> li = Arrays.asList(1, 2, 3, 4, 5, 6);

		// logic for the operation
//		System.out.println("Sum of Even numbers are : "+ li.stream()
//		.filter(x->x%2==0)
//		.reduce(0,(a,b)->a+b));

		// using predicate
		Predicate<Integer> predicate = x -> x % 2 == 0;

		li.forEach(x -> {
			if (predicate.test(x)) {
				sum += x;
			}
		});

		System.out.println("Sum of Even numbers are : "+sum);

	}
}

/*
 * output Sum of Even numbers are : 12
 */
