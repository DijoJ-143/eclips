package com.ust.Task.Taskgiven.person;

public class Person {

	// properties
	private String First_name;
	private String Second_name;
	private int age;
	private String gender;

	// constructor
	public Person(String first_name, String second_name, int age, String gender) {
		super();
		First_name = first_name;
		Second_name = second_name;
		this.age = age;
		this.gender = gender;
	}

	// getter and setter
	public String getFirst_name() {
		return First_name;
	}

	public void setFirst_name(String first_name) {
		First_name = first_name;
	}

	public String getSecond_name() {
		return Second_name;
	}

	public void setSecond_name(String second_name) {
		Second_name = second_name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "Person { \nName :" + First_name + " " + Second_name + ", \nage : " + age + ", \ngender : " + gender
				+ "\n} \n";
	}

}
