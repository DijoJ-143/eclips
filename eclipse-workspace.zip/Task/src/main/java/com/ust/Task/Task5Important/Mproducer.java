package com.ust.Task.Task5Important;

public class Mproducer extends Thread {
	// properties
	private final MmessageManager manager;
	private int mid;
	private String message;

	// constructor
	public Mproducer(MmessageManager manager, int mid, String message) {
		super();
		this.manager = manager;
		this.mid = mid;
		this.message = message;
	}

	// run method

	@Override
	public void run() {
		// TODO Auto-generated method stub
		while (true) {
			manager.addMessage(new Mmessage(mid, message));
			System.out.println("Producer : send :: " + this.message);
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO: handle exception
				Thread.currentThread().interrupt();
			}
		}
	}

}
