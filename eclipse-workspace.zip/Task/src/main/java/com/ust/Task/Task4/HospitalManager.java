package com.ust.Task.Task4;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class HospitalManager {

	private List<Patient> plist;
	private List<Doctor> dlist;
	private List<Appointment> alist;

	// constructor
	public HospitalManager() {

		plist = new ArrayList<>();
		dlist = new ArrayList<>();
		alist = new ArrayList<>();
	}

	// adding patient
	public void addPatient(Patient patient) {

		plist.add(patient);
		System.out.println("\n Mr." + patient.getPname() + "  added successfully");

	}

	// adding Doctor
	public void addDoctor(Doctor doctor) {

		dlist.add(doctor);
		System.out.println("\n Dr." + doctor.getDname() + "  added successfully");

	}

	// scheduling appoinment
	public void scheduleAppointment(int appointmentId, int patientId, int doctorId, LocalDateTime dateTime) {
		Patient pat = plist.stream().filter(P -> P.getPid() == patientId).findFirst().orElse(null);
		Doctor doc = dlist.stream().filter(P -> P.getDid() == doctorId).findFirst().orElse(null);

		if (pat != null && doc != null) {
			alist.add(new Appointment(appointmentId, pat, doc, dateTime));
			System.out.println("\n________________APPOINMENT BOOKED FOR_______________\n");
			System.out.println("\n patient : "+ pat.getPname());
			System.out.println("\n Doctor : "+ doc.getDname()+"\n");
			
		} else
			System.err.println("Appoinment booking denied\n");

	}

	// listing all patient
	public void listAllPatient() {
		System.out.println("\n************PATIENTS DATA**********\n");
		if (!plist.isEmpty()) {
			plist.forEach(System.out::println);

		}

	}

	// listing all doctors
	public void listAllDoctors() {
		System.out.println("\n************Doctors DATA**********\n");
		if (!dlist.isEmpty()) {
			dlist.forEach(System.out::println);

		}

	}

	// listing all appoinment
	public void listAllAppoinment() {
		System.out.println("\n************Appoinment DATA**********\n");
		if (!alist.isEmpty()) {
			alist.forEach(System.out::println);

		}

	}

}
