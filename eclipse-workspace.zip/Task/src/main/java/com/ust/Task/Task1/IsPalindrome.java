package com.ust.Task.Task1;

import java.util.Scanner;

//chechking whether the string is palindrome or not
public class IsPalindrome {

	static Scanner sc = new Scanner(System.in);

	public static void main(String[] args) {

		// input a string
		System.out.println("Enter a string");
		String input = sc.next();

		// checking the condition
		if (isPalindrome(input))
			// printing the output
			System.out.println(input + " is a palidrome");
		else
			System.err.println(input + " is not palidrome");

	}

	/*
	 * parametreised method with boolean return type to analyze whether the string
	 * is palindrome or not
	 */

	public static boolean isPalindrome(String input) {

		StringBuffer sb = new StringBuffer(input);
		return sb.reverse().toString().equalsIgnoreCase(input);

	}

}

/*
 * output
 *  Enter a string malayalam
 *   malayalam is a palidrome
 */
