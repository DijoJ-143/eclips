package com.ust.Task.STUDYINGANDDOUBT;

public class Solution {
	public static String mergeAlternately(String word1, String word2) {

		StringBuffer result = new StringBuffer();

		int i = 0;

		while (i < word1.length() || i < word2.length()) {
			if (i < word1.length()) {
				result = result.append(word1.charAt(i));
			}
			if (i < word2.length()) {
				result = result.append(word2.charAt(i));
			}
			i++;
		}

		return result.toString();

	}

	public static void main(String[] args) {
		System.out.println(mergeAlternately("abc", "pqr"));
	}
}
