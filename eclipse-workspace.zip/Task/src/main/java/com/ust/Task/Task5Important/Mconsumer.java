package com.ust.Task.Task5Important;

public class Mconsumer extends Thread {
	// properties
	private final MmessageManager manager;

	// constructor
	public Mconsumer(MmessageManager manager) {
		super();
		this.manager = manager;

	}

	// run method

	@Override
	public void run() {
		// TODO Auto-generated method stub

		while (true) {
			try {
				System.out.println("Consumer : received :: " + manager.retrieveMessage());
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO: handle exception
				Thread.currentThread().interrupt();
			}
		}
	}

}
