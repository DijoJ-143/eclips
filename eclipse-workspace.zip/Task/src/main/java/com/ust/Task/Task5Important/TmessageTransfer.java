package com.ust.Task.Task5Important;

//extends thread class
public class TmessageTransfer extends Thread {

	// properties
	private String msg;
	Ttranfer msgTransfer;

	public TmessageTransfer(String msg, Ttranfer msgTransfer) {
		super();
		this.msg = msg;
		this.msgTransfer = msgTransfer;
	}

	// logic
	@Override
	public void run() {
		// TODO Auto-generated method stub
		super.run();
		// making it synchronized one
		synchronized (msgTransfer) {
			msgTransfer.sendMessage(msg);

		}
	}

}
