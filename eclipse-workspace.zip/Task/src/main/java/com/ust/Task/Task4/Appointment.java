package com.ust.Task.Task4;

import java.time.LocalDate;
import java.time.LocalDateTime;

public class Appointment {
	// details
	private int Aid;
	private Patient patient;
	private Doctor doctor;
	private LocalDateTime localDateTime;

	// constructor
	public Appointment(int aid, Patient patient, Doctor doctor, LocalDateTime localDateTime) {
		super();
		Aid = aid;
		this.patient = patient;
		this.doctor = doctor;
		this.localDateTime = localDateTime;
	}

	// getter and setter
	public int getAid() {
		return Aid;
	}

	public void setAid(int aid) {
		Aid = aid;
	}

	public Patient getPatient() {
		return patient;
	}

	public void setPatient(Patient patient) {
		this.patient = patient;
	}

	public Doctor getDoctor() {
		return doctor;
	}

	public void setDoctor(Doctor doctor) {
		this.doctor = doctor;
	}

	public LocalDateTime getLocalDateTime() {
		return localDateTime;
	}

	public void setLocalDateTime(LocalDateTime localDateTime) {
		this.localDateTime = localDateTime;
	}

	@Override
	public String toString() {
		return "APPOINMENT DATA [ " + getAid() + " || " + getPatient() + " || " + getDoctor() + " || "
				+ getLocalDateTime() + " ]";
	}
}
