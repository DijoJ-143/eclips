package com.ust.Task.Task5Important;

import java.util.ArrayList;

public class ObjectRemoving {
	public static void main(String[] args) {
		ArrayList<Integer> al = new ArrayList<>();
		al.add(1);
		al.add(3);
		al.add(2);
		al.add(1);
		System.out.println(al);
		
		System.out.println(al.remove(1));
		
		System.out.println(al.remove(Integer.valueOf(2)));
		System.out.println(al);
		
	}

}
