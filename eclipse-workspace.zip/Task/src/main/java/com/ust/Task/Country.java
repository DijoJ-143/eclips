package com.ust.Task;

public class Country {
	String name;
	
	public Country(String name) {
		super();
		this.name = name;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return name;
	}
	public static void main(String[] args) {
		
		Country[] clist = {new Country("india"),new Country("USA")};
		for(Country c:clist) {
			System.out.println(c.name);
		}
	}

}
