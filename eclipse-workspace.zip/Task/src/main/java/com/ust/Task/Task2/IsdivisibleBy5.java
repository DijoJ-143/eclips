package com.ust.Task.Task2;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

/*
 * check if there is any number in a list that is divisible by 5 and return a boolean value indicating the presence of such a number
 */
public class IsdivisibleBy5 {

	public static void main(String[] args) {
		// Variables
		int size;
		Scanner sc = new Scanner(System.in);

		// input size
		System.out.println("Enter the size of list");
		size = sc.nextInt();

		// creating a list
		List<Integer> li = new ArrayList<>(size);
		// input numbers

		for (int i = 0; i < size; i++) {
			System.out.println("Enter the num" + i + " : ");
			li.add(sc.nextInt());
		}

		System.out.println("contains number divisible by 5 :" + passTheList(li));

	}

	public static boolean passTheList(List<Integer> li) {

		List<Integer> li2 = li.stream().filter(x -> x % 5 == 0).collect(Collectors.toList());
		return li2.size() > 0;
	}

}
