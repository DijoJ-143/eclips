package com.ust.Task.Task5Important;

public class Ttranfer {

	//method which accepts string 
	public void sendMessage(String message) {
		System.out.println(message + " ...is sending");
		try {
			Thread.sleep(1000);

		} catch (InterruptedException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		System.out.println(message + " ...is send DONE[✔✔]");
	}

}
