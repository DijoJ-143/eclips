package com.ust.Task.Task6File;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.Vector;

public class EmployeeManager {

	private Vector<Employee> data;

	// constructor
	public EmployeeManager() {

		super();
		data = new Vector<>();
	}

	// adding employees to the vector
	public void addEmployee(Employee e) {
		data.add(e);

	}

	// find employee using id
	public Employee findBiyId(int id) {
		Employee e = data.stream().filter(e1 -> e1.getId() == id).findFirst().orElse(null);

		if (e != null) {
			return e;
		} else {
			System.err.println("invalid employee id");
		}
		return null;
	}

	// printing the data of employee using file.write
	public void printEmployeeDataInPath(int id, String path) {
		// creating a path with the help of java11.
		Path path2 = Path.of(path);
		Employee e = findBiyId(id);
		if (e != null) {
			byte[] dataOfEmployee = e.toString().getBytes();
			try {
				// files.write (java7)
				Files.write(path2, dataOfEmployee, StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
				System.out.println("Data transfered to the file... " + path);
			} catch (Exception e2) {
				// TODO: handle exception
				System.out.println("Error in writing to the file.... " + path);

			}

		} else {
			System.err.println("invalid employee id : " + id);

		}

	}
}
