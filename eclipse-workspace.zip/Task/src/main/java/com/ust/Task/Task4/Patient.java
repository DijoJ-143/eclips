package com.ust.Task.Task4;

public class Patient {
	/*
	 * Defining properties such as id , name , and contactInfo
	 */

	// id
	private int pid;
	// name
	private String pname;
	// contactinfo
	private String pcontactInfo;

	// constructor
	public Patient(int pid, String pname, String pcontactInfo) {
		super();
		setPid(pid);
		setPname(pname);
		setPcontactInfo(pcontactInfo);
	}

	public int getPid() {
		return pid;
	}

	public void setPid(int pid) {
		this.pid = pid;
	}

	public String getPname() {
		return pname;
	}

	public void setPname(String pname) {
		this.pname = pname;
	}

	public String getPcontactInfo() {
		return pcontactInfo;
	}

	public void setPcontactInfo(String pcontactInfo) {
		this.pcontactInfo = pcontactInfo;
	}

	@Override
	public String toString() {
		return "Patient info[ " + getPid() + " || " + getPname() + " || " + getPcontactInfo() + " ]";
	}

}
