package com.ust.Task.Task5Important;

public class Mmain {
    public static void main(String[] args) throws InterruptedException {
        MmessageManager m1 = new MmessageManager();
        Mproducer p1 = new Mproducer(m1, 1, "hai");
        Mproducer p2 = new Mproducer(m1, 2, "respond me");
        Mconsumer c1 = new Mconsumer(m1);

        p1.start();
        p2.start();
        c1.start();

        // Wait for a while to let the producers add some messages
        Thread.sleep(3000);

        // List all messages after some time
        m1.listAllMessages();
    }
}
