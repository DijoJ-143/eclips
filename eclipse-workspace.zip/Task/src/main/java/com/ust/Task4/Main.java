package com.ust.Task4;

public class Main {
	public static void main(String[] args) {
		StudentManager s = new  StudentManager();
		s.addStudent(new Student(1, "dijo", 90.0));
		s.listAllStudents();
		s.updateStudentGrade(1, 91);
		s.listAllStudents();
		
		s.clearAllStudents();
		s.listAllStudents();
		System.out.println("-------------------new List----------------");
		s.addStudent(new Student(1, "Dj", 100));
		s.addStudent(new Student(2, "Jdj", 100));
		s.addStudent(new Student(3, "Aj", 100));
		s.sortStudentsByName();
		s.listAllStudents();
		System.out.println("------------------grade having 100----------");
		s.findStudentsByGrade(100);
	}

}
