package com.ust.Task4;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class StudentManager {
	// student list
	ArrayList<Student> students;

	// constructor
	public StudentManager() {
		students = new ArrayList<>();
	}

	// addStudent
	public void addStudent(Student s) {

		students.add(s);
	}

	// remove Student
	public void remove(int id) {

		students.removeIf(student -> student.getsId() == id);
	}

	// getSTudent by id
	public Student getStudent(int id) {
		return students.stream().filter(student -> student.getsId() == id).findFirst().orElse(null);
	}

	// updateStudentGrade
	public void updateStudentGrade(int id, double newGrade) {

		Student s = getStudent(id);
		if (s != null)
			s.setsGrade(newGrade);
		else
			System.out.println("invalid stduent id");

	}

	// `listAllStudents

	public void listAllStudents() {

		students.forEach(System.out::println);

	}

	// sortStudentsByName
	public void sortStudentsByName() {
		students.sort(Comparator.comparing(Student::getsName));

	}

	// findStudentsByGrade
	public void findStudentsByGrade(double grade) {
		List<Student> stu = students.stream().filter(student -> student.getsGrade() == grade).collect(Collectors.toList());
		stu.forEach(student-> System.out.println(student));
	}

	// Get the total number of students
	public int getNumberOfStudents() {
		return students.size();
	}

	// Clear all students from the list
	public void clearAllStudents() {
		students.clear();
	}

}
