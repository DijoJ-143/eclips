package com.ust.Task4;

public class Student {

	// student id
	private int sId;
	// student name
	private String sName;
	// student grade
	private double sGrade;

	// constructor
	public Student(int sId, String sName, double sGrade) {
		setsId(sId);
		setsGrade(sGrade);
		setsName(sName);
	}

	public int getsId() {
		return this.sId;
	}

	public void setsId(int sId) {
		this.sId = sId;
	}

	public String getsName() {
		return this.sName;
	}

	public void setsName(String sName) {
		this.sName = sName;
	}

	public double getsGrade() {
		return this.sGrade;
	}

	public void setsGrade(double sGrade) {
		this.sGrade = sGrade;
	}

	// toString method overriding

	public String toString() {

		return "\nStudent id : " + getsId() + " || Student name : " + getsName() + " || Student Grade : " + getsGrade();
	}

}
