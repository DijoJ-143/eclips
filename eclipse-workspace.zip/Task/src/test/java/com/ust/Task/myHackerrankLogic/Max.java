package com.ust.Task.myHackerrankLogic;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Max {
	public static void main(String[] args) {
		int[] a= {1,2,3,3,4,4,4,4,4,5,6};
		int b= 0;
		if(b>1) {
			System.out.println("1");
			
			
		}
		else if (b<1) {
			System.out.println("0");

		}
		else {
			System.out.println("1");

		}
		
	}

}
