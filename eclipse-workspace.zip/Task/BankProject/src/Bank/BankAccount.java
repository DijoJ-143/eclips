package Bank;

//created an interface
public interface BankAccount {

	// deposit method
	void deposit(double amount);

	// withdraw method
	public abstract void withdraw(double amount);

	// getBalance method
	public abstract double getBalance();

	// 1.obj*
	// 2.public nonstatic abstract
	// 3.public static final

}
