package Bank;

import java.util.ArrayList;

public class Bank {
	// property
	private ArrayList<Account> accounts;

	// constructor
	public Bank() {
		accounts = new ArrayList<>();
	}

	// adding account
	public void addAccount(Account account) {
		accounts.add(account);
	}

	// finding account
	public Account findAccount(String accountNumber) {
		for (Account a : accounts) {
			if (a.getAccoutNumber().equals(accountNumber)) {
				return a;
			}
		}
		System.err.println("invalid acc no: "+accountNumber);
		return null;
	}

	// depositeToAccount
	public void depositeToAccount(String accountNumber, double amount) {
		
	
		Account account = findAccount(accountNumber);

		if (account != null) {
			account.deposit(amount);
		}

	}

	// WithdrawfromAccount
	public void WithdrawFromAccount(String accountNumber, double amount) {
		
		Account account = findAccount(accountNumber);

		if (account != null) {
			account.withdraw(amount);
		}

	}

//printing the balance

	public void printBalance(String accountNumber) {
		Account account = findAccount(accountNumber);

		if (account != null) {
			System.out.println(account.getBalance());

		}

	}
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "ITS AN OBJECT OF BANK CLASS";
	}

}
