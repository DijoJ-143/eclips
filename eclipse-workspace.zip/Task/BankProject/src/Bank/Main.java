package Bank;

public class Main {
	public static void main(String[] args) {
		Bank bank = new Bank();
		
		Account savingsAccount =  new SavingsAccount("123", 20000, 2.5);
		Account currentAccount = new  CurrentAccount("345", 10000, 500);
		
		bank.addAccount(savingsAccount);
		bank.addAccount(currentAccount);
		
		bank.depositeToAccount("123", 10000);
		bank.printBalance("123");
		bank.printBalance("1234");
	}

}
