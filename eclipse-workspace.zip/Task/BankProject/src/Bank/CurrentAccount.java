package Bank;

public class CurrentAccount extends Account {
	// overdraftLimit
	private double overdraftLimit;

	// constructor
	public CurrentAccount(String accountNumber, double balance, double overdraftLimit) {
		super(accountNumber, balance);
		this.overdraftLimit = overdraftLimit;
		// TODO Auto-generated constructor stub
	}

	@Override
	public void withdraw(double amount) {
		// TODO Auto-generated method stub
		if (amount > 0 && balance + overdraftLimit >= amount)
			balance -= amount;
		else
			System.out.println("overdraft limit reached or invalid withdrawal amount.");

	}

}
