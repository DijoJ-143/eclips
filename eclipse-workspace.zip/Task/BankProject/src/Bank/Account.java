package Bank;

public abstract class Account implements BankAccount {

	// properties
	private String accoutNumber;
	protected double balance;

	// constructor
	public Account(String accountNumber, double balance) {
		this.accoutNumber = accountNumber;
		this.balance = balance;
	}

//methods
	@Override
	public void deposit(double amount) {
		if (amount > 0) {
//			balance = balance+amount;
			balance += amount;

		} else {
			System.out.println("Invalid amount");
		}
	}

	// abstract method
	public abstract void withdraw(double amount);

	@Override
	public double getBalance() {
		return balance;

	}

	// getter
	public String getAccoutNumber() {
		return accoutNumber;
	}

	// setter
	public void setAccoutNumber(String accoutNumber) {
		this.accoutNumber = accoutNumber;
	};

}
