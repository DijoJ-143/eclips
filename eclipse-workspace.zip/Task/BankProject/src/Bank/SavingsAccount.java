package Bank;

public class SavingsAccount extends Account {
	// interest rate
	private double interestRate;

	//constructor
	public SavingsAccount(String accountNumber, double balance, double interestRate) {
		super(accountNumber, balance);
		this.interestRate = interestRate;
		// TODO Auto-generated constructor stub
	}

	// addInterest()
	public void addInterest() {
		balance += balance * interestRate / 100;
		// balance = balance + balance * intRate/100

	}

	@Override
	public void withdraw(double amount) {
		// TODO Auto-generated method stub
		if (amount > 0 && amount <= balance) {
//			balance = balance - amount;
			balance -= amount;
		}
		else
			System.out.println("Insufficient Fund");

	}

	/*
	 * 
	 * 
	 * withdraw 10 balance 15 b= 15-10=5
	 * 
	 * 
	 * b=9 w=15 insufficient bal
	 * 
	 */
}
