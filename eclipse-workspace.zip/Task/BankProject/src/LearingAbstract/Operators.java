package LearingAbstract;

public class Operators {
	public static void main(String[] args) {
		int balance =10;
		int amount = 15;
		
		if(balance >0 || amount<balance)
			System.out.println("balance is greater than 0 and amount is lesser");
		else {
			System.out.println("amount");
			System.out.println("is ");
			System.out.println("greater");
			}
		/*
		 * and (both)
		 * 
		 * true && true ->true
		 * true && false -> false
		 * false &&  true -> false
		 * false && false -> false
		 * 
		 */
		
		/* oR(any one)
		 *  true || true ->true
		 * true ||false -> true
		 * false ||  true -> true
		 * false || false -> false
		 * 
		 */
		
	}

}
