//package LearingAbstract;
//
//public class Main {
//	public static void main(String[] args) {
//
//		// creates an arraylist of account type
//		Bank bank = new Bank();
//
//		// creating accounts
//		SavingsAccount savingsAccount = new SavingsAccount("SA123", 1200.0, 2.0);
//		CurrentAccount currentAccount = new CurrentAccount("CA123", 1110.0, 100.0);
//
//		// adding the accounts to list
//		bank.addAccount(savingsAccount);
//		bank.addAccount(currentAccount);
//
//		// performing transactions
//		System.out.println("deposite : before");
//		bank.printBalance("SA123");
//		bank.depositeToAccount("SA123", 1000);
//		System.out.println("deposite : after");
//		bank.printBalance("SA123");
//		System.out.println("--------------------------------------");
//		System.out.println("withdraw before");
//		bank.printBalance("CA123");
//		bank.withdrawFromAccount("CA123", 1200);
//		System.out.println("withdraw after");
//		bank.printBalance("CA123");
//
//	}
//
//}
