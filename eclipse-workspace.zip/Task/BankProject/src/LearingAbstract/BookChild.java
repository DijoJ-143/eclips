// package LearingAbstract;
//
//public class BookChild extends Book{
//
//	public BookChild(String title) {
//		super(title);
//		// TODO Auto-generated constructor stub
//	}
//
//	@Override
//	public void price() {
//		// TODO Auto-generated method stub
//		System.out.println("child");
//		
//	}
//	
//	public static void main(String[] args) {
//	
//	
//		BookChild  bc = new BookChild("chetan");
//		bc.price();
//	}
//
//}
