//package LearingAbstract;
//
//public abstract class Book {
//	// properties
//	String title;
//
//	// cons
//	public Book(String title) {
//
//		this.title = title;
//	}
//
//	// non-static method
//	//concrete met..
//	public  void iRead() {
//
//		System.out.println("I read the book");
//
//	}
//	
//	//abstract method
//	public abstract void price();
//	
//
//	// main method
//	public static void main(String[] args) {
//		
//		Book b1 = new Book("Gopi");
////		Book.iRead();
//		b1.iRead();
//		
//
//
//	}
//
//}
