package LearingAbstract;

public  class Soap {


	 String brandname;

	//constructor
/*
 * this-> current object reffernce ;
 * Soap s= new Soap("Chetan");
 * s=Bank.Soap@5f184fc6
 * 
 */

	 
	public Soap(String name) {
		this.brandname= name;
		
	}

	public static void main(String[] args) {
	
//		classname objectreference = new constructor();
//		Soap s1 = new Soap();
	
		
		Soap s= new Soap("Chetan");
		Soap s2= new Soap("Chetan");
		Soap s3= new Soap("Chetan");
		System.out.println(s);
		System.out.println(s2);
		System.out.println(s3);
		System.out.println(s.brandname);
		
		
		
		
		
		
		
	}

}
