package List;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Vector;

public class Lists {
	public static void main(String[] args) {
//		//adding
////		1.add(object); type is boolean
//		
//		
//		
//		List l = new ArrayList<>();
////		System.out.println(l.add(l));
//		l.add(1);//0
//		l.add(1);//1
//		l.add(1);//2
//		l.add("gopi");//3
//		l.add("chetan");//4
//		
//		
//		
//		System.out.println(l);
////		add(int index, object o) type is void
//		l.add(2,'a' );
//		
//		System.out.println(l);
//		
//		//add(collection)
//				l.addAll(l);
//				
//		
//		System.out.println(l);
		//removing
		
//		l.remove(0);
//		System.out.println("remove 0th index : "+l);
//		l.clear();
//		System.out.println("clear : "+l);
		ArrayList al = new ArrayList<>();
		al.add(1);
		al.add(2);
		al.add(3);
		al.add(3.0f);
		al.add('a');
		
		
		System.out.println(al);
		
////		al.remove(2);
////		System.out.println(al);
//		al.remove(Integer.valueOf(3));
//		al.remove(Float.valueOf(3.0f));//double
//		System.out.println(al);
		//access
		
//		System.out.println(al.get(3));
		
		
		
		//search
		
		ArrayList<Float> al1 = new ArrayList<>();
		
		al1.add(3.0f);
		System.out.println(al1);
	}

}
