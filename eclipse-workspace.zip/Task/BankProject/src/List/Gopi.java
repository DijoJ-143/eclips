package List;

import java.util.ArrayList;

public class Gopi {

	
	public static void main(String[] args) {
		//dynamic / growable array 
//		int[] arr = new int[2];
//		arr[0]=1;
//		arr[1]=2;
////		arr[2]=3;
////		System.out.println(arr[2]);
		
		
		
	ArrayList al = new ArrayList();
		//add(object)
		al.add(1.0f);//0
		al.add(al);//1
		al.add("string");//2
		//1 i a float is a primitive type so how its beconme an object
//		System.out.println(al.get(0));
		System.out.println(al.get(0).getClass());
		System.out.println(al.get(1).getClass());
		System.out.println(al.get(2).getClass());
//		System.out.println(al.get(0).getClass());
	
		
		
		
		
		
	}
}
