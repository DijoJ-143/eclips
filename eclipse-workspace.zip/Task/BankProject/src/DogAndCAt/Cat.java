package DogAndCAt;

public class Cat implements Animal {

	@Override
	public void sound() {
		// TODO Auto-generated method stub
		System.out.println("meow meow");
	}

}
