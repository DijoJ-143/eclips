package DogAndCAt;

public class VariableSpecifying {
	public static void main(String[] args) {
//		Tea mug = tea;
	String a= "string";
//	datatype variablename = data;
	
	String name1 = "pooja" ;
	String name2 ="jothi";
	String name3 = "dijo";
//	System.out.println(name2);
	
	//datatype[] variablename = new datatype[size];
	
	
	int[] numbers = new int[3];
	
//	0----(size-1)
//	0---(3-1)->0-2;
	
	numbers[0]=1;
	numbers[1]=2;
	numbers[2]=3;
//	numbers[3]=3;
	
	System.out.println("length:"+numbers.length);
	
	
	
	
	
//for(intializing;condition;updation/increment or decre)
	for(int index=0;index<=numbers.length;index++ ) {
		
		System.out.println(numbers[index]);
	}
		
	}
	
	
	
	//LIST 
	
	
	
	
	
	
	
	

}
