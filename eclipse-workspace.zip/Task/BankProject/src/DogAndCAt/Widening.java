package DogAndCAt;

public class Widening {
	public static void main(String[] args) {
//		byte<short,char<int<long<float<double
		//implicitly -> automatically
		byte pieceofMetal=1;
		int bigMetal=pieceofMetal;
		
		System.out.println(bigMetal);
		
		
	}

}
