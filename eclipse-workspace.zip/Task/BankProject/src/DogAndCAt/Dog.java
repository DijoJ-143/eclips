package DogAndCAt;

public class Dog  implements Animal{

	@Override
	public void sound() {
		// TODO Auto-generated method stub
		System.out.println("bow bow");
	}

}
