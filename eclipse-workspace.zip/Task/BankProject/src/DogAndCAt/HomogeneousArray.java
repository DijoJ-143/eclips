package DogAndCAt;

import java.util.Arrays;
import java.util.List;

public class HomogeneousArray {
	public static void main(String[] args) {
		char[] array = { (char) 100000, 2, 'a', 'b' };
		

//		System.out.println(array[0]);
	}

}
