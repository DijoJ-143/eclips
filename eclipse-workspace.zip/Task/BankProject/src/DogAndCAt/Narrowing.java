package DogAndCAt;

public class Narrowing {
	public static void main(String[] args) {
//		byte<short,char<int<long<float<double
		
		float f1= 1;
		System.out.println(f1);
		
		//typecast operator
		int num1 = (byte)f1;
		
		System.out.println(num1);
		
	}

}
