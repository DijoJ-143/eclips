package DogAndCAt;

public interface Animal {
	void sound();

}
