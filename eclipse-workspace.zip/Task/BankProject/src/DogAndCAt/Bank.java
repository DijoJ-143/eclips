//package DogAndCAt;
//
//import java.util.ArrayList;
//
//public class Bank {
//
//	// creating an account type arrayList
//	private ArrayList<Account> accounts;
//
//	// constructor
//	public Bank() {
//		super();
//		accounts = new ArrayList<>();
//	}
//
//	// Adding an account
//	public void addAccount(Account account) {
//
//		accounts.add(account);
//
//	}
//
//	// finding account
//	/*
//	 * with the help of account number trying to fetch it from current object array
//	 * list if founds return account else null
//	 */
//	public Account findAccount(String accountNumber) {
//		for (Account account : accounts) {
//			if (account.getAccoutNumber().equals(accountNumber)) {
//				return account;
//			}
//		}
//
//		return null;
//	}
//
//	// depositToAccount
//	/*
//	 * with the help of account number trying to fetch the account from the current
//	 * object arraylist if fount deposite is done else invalid account is thrown
//	 */
//
//	public String depositeToAccount(String accountNumber, double amount) {
//
//		Account acc = findAccount(accountNumber);
//		if (acc != null) {
//			acc.deposit(amount);
//			return "deposite successfull";
//		} else
//			return "unable to find the account";
//
//	}
//
//	// performing withdrawal
//	/*
//	 * fetch the account using accountNumber if found based on the withdrawal method
//	 * try to withdraw the amount
//	 * 
//	 * late instatiation
//	 * 
//	 * although the parent class have the method withraw but its abstract, the child
//	 * class determines the withdrawl operation
//	 */
//
//	public void withdrawFromAccount(String accountNumber, double amount) {
//		Account acc = findAccount(accountNumber);
//		if (acc != null) {
//			acc.withdraw(amount);
//		} else
//			System.out.println("Account not found");
//
//	}
//
//	// printing the balance
//
//	public void printBalance(String accountNumber) {
//
//		Account acc = findAccount(accountNumber);
//		if (acc != null) {
//
//			System.out.println(acc.getAccoutNumber() + " : " + acc.getBalance());
//
//		} else
//			System.out.println("invalid Account number");
//	}
//
//}
