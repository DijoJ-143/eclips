package DogAndCAt;

public class Numbers {
	public static void main(String[] args) {
		
		Numbers n = new Numbers();
		
		String s= "a is a character";
		
		//integer
		byte num2 = 124;
		short num3 = 10000;
		int num =1000000000;
		long num4 = 1000000000000000000l;
		long num44= 1l;
		
		
	//float
		float f =10;
		double d1 = 10.0d;
		
	//character
		char c1= 'a';
		
		char c2= 56;
		
//		System.out.println(c1);
		
	//Boolean
		boolean b1= true;
		boolean b2= false;
		
		
		//array
		
		int[] bucket= {1,2,3,4,5,6};
		System.out.println(bucket[5]);
		
		
		
		
	}

}
