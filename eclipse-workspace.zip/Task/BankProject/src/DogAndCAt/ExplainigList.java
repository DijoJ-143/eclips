package DogAndCAt;

import java.util.ArrayList;
import java.util.List;

public class ExplainigList {
	public static void main(String[] args) {
		List mylist = new ArrayList<>() ;
		
		ArrayList mynewArrayList = new ArrayList<>();
//		add()
		
		mynewArrayList.add(1);
		
		
	}

}
