package DogAndCAt;

import java.util.ArrayList;

public class MAin {
	public static void main(String[] args) {
		ArrayList<Animal> animals = new ArrayList<>();
		
//		Dog d = new Dog();
//		Cat c = new Cat();
//		
//		Animal a = new Dog();
		
		
		animals.add(new Dog());
		animals.add(new Cat());
		
		for(Animal animal: animals) {
			animal.sound();
		}
	}

}
