package DogAndCAt;

public class StaticAndNonstatic {
	//global 
	
	int a= 10;//nonstatic
	static int b = 11;//static
	
	public static void main(String[] args) {
		//localvariable
		
		
		StaticAndNonstatic static1 = new StaticAndNonstatic();
		StaticAndNonstatic static2 = new StaticAndNonstatic();
		StaticAndNonstatic static3 = new StaticAndNonstatic();
		
		static1.b= 12;
		System.out.println(static2.b);
		System.out.println(static3.b);
		
		static1.a=11;
		System.out.println(static2.a);
		System.out.println(static3.a);
		
		
	}

}
