package DogAndCAt;

public class Wrapperclass {
	public static void main(String[] args) {
		byte b = 10;
		Byte b1= b;
		System.out.println(b1+10);
		
		//non primitive dt
		String num="10";
		System.out.println(num+num);
		
		
		
		
	}

}
