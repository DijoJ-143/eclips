package STUDENTS;

public class Main {
	public static void main(String[] args) {
		
		Student s1 = new Student(1, "chetan", 60);
		Student s2 = new Student(2, "gopi", 80);
		Student s3 = new Student(3, "jothi", 70);
		Student s4 = new Student(4, "Dijo", 70);
		
		StudentManger manger = new StudentManger();
		
		//adding
		manger.addStudent(s1);
		manger.addStudent(s2);
		manger.addStudent(s3);
		manger.addStudent(s4);
		
		//list student
		manger.ListAlltheStudents();
		
		//remove
		manger.removeStudentById(4);
		System.out.println("------after removing-------");
		manger.ListAlltheStudents();
		
		//find the student
		System.out.println("------output for the finding operation------");
		manger.findStudentById(4);
		
	}

}
