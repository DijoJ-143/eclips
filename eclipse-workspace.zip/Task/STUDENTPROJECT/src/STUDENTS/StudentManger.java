package STUDENTS;

import java.util.ArrayList;

public class StudentManger {
	//properties
	private ArrayList<Student> students;
	
	//constructor
	public StudentManger() {
		this.students= new ArrayList<>();
	}
	
	//adding student
	public void addStudent(Student s) {
		students.add(s);
		
	}
	//find the student
	public Student findStudentById(int id) {
		for(Student s : students) {
			if(s.getId()==id)
				return s;
			
		}
		
		System.err.println("The given id is not valid :" +id);
		
			return null;
	}
	//remove
	public void removeStudentById(int id) {
		Student s=findStudentById(id);
		
		if(s!=null) {
			students.remove(s);
		}
		
	}
	
	
	//update
	public  void updateStudentByid(int id ,double grade) {
	Student s=findStudentById(id);
	
	if(s!=null) {
		s.setGrade(grade);
	}
}
	
	//list all the student
	public void ListAlltheStudents() {
		for(Student s : students) {
			System.out.println(s);
		}
	}
	
	//get the number of students
	public void getNumberOfStudents() {
		if(students!=null)
			System.out.println("Total number of students : "+students.size());
	}
	
	//clear
	public void clearAllthedata() {
		students.clear();
	}
	

}
