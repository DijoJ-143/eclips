package STUDENTS;

import java.util.ArrayList;

public class DOubt2 {
	public static void main(String[] args) {
//		ArrayList<Student> al = new ArrayList<>();
//		al.add(new Student(1, null, 0));
//		al.add(new Student(2, null, 0));
//		al.add(new Student(3, null, 0));
//		al.add(new Student(4, null, 0));
//		al.add(new Student(5, null, 0));

		
		
		ArrayList al2 = new ArrayList();
		al2.add(2);
		al2.add(3);
		al2.add(new Student(6, null, 0));
		
		for (Object obj : al2) {
			
			System.out.println(obj);
			
		}
		
		
		
		
//		for (Student s : al) {
//			
//			System.out.println(s);
//		}
	}

}
