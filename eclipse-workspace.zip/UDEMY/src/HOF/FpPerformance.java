package HOF;

import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class FpPerformance {
	public static void main(String[] args) {
		
	long milisec = System.currentTimeMillis();
		
		
		Stream.of("cow", "matt", "hatt", "saaaaaaat", "sfaaaaaat")
				.peek(System.out::println)
				.filter(c -> c.length() > 5)
				.map(String::toUpperCase)
				.parallel()
				.peek(System.out::println)
				.findFirst();
		System.out.println(System.currentTimeMillis()-milisec);
		
//		System.out.println(IntStream.rangeClosed(1,10).boxed().collect(Collectors.toList()));
		
	}

}
