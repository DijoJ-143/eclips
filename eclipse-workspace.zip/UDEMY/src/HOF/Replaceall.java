package HOF;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Replaceall {
	
	public static void main(String[] args) {
		List<String> mutable = Arrays.asList("string","spring","hai");
		
		System.out.println(mutable);
		mutable.replaceAll(String::toUpperCase);
		
		System.out.println(mutable);
		
		List<String> mutableasItsnotreturningArray = new ArrayList(Arrays.asList("string","spring","hai"));
		
		mutableasItsnotreturningArray.removeIf(str -> str.length()<4);	
		System.out.println(mutableasItsnotreturningArray);
	}

}
