package tryingnewLogic;

import java.util.Scanner;

public class LongestWord {
	
	static Scanner sc = new Scanner(System.in);
	
	
	static int  year= getInput()  ;
	
	static int  age = calculateage(year);
	
	public static int calculateage( int year) {
		return 2025-year;
	}
	
	public static int getInput() {
		System.out.println("enter your birth year");
		
		return sc.nextInt();
	}
	
	
	public static void main(String[] args) {
		
		
		
		System.out.println("You are : "+age+" yrs old");
		
	}
	}
//		Scanner sc = new Scanner(System.in);
		
//		System.out.println(FindTheLongest(sc.nextLine()));
//	}
//	
//	
//	public static String FindTheLongest(String s) {
//	return Arrays.stream(s.split(" ")).max(Comparator.comparingInt(String::length)).orElse(null);
//	}
	
	
	


