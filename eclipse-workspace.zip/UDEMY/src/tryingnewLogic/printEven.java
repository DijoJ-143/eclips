package tryingnewLogic;

import java.util.List;

public class printEven {
	public static void main(String[] args) {
		printEvenNumber(List.of(1, 2, 3, 4, 5, 6));
	}

	private static void printEvenNumber(List<Integer> numbers) {
		// TODO Auto-generated method stub
		
		//using filter
		System.out.println("using filter");

		numbers.stream().filter(x->x%2==0).forEach(System.out::println);
		//without filter
		System.out.println("without filter");

		numbers.stream().forEach(
				x->{if(x%2==0) {
			System.out.println(x);
			
		}
				}
				);
		
	}

}
