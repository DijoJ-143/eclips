package tryingnewLogic;

public class THISKEYWORD {
	

	
	public static void main(String[] args) {
		
		for(System.out.println("qwertyui");true;System.out.println("hai all")) {
			
		}
		
		
		
		
	}

}
