package Threads;

import java.util.Iterator;
import java.util.stream.IntStream;

public class F20 {
	public static void main(String[] args) {
		Runnable count1 = () -> {

			IntStream.rangeClosed(1, 10).forEach(i ->

			System.out.println(Thread.currentThread().getId() + ": count:" + i + ""));

		};

		Thread t1 = new Thread(count1);
		Thread t2 = new Thread(count1);
		Thread t3 = new Thread(count1);
		t1.start();
		t2.start();
		t3.start();
	}

}
