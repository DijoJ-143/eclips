package Topics;

import java.util.Arrays;
import java.util.List;

public class Reduce {
	
	static int count;
	public static void main(String[] args) {
		System.out.println("sum = " + sumofValues(Arrays.asList(1, 2, 3, 4, 5)));
		
		

	}

	public static int sum(int aggregate, int nextnumber) {
	count++;
	
	System.out.println("step "+count+" : "+aggregate+"+"+nextnumber+":"+ Math.addExact( aggregate ,nextnumber));
		
		return aggregate + nextnumber;
	}

	private static int sumofValues(List<Integer> asList) {
		// TODO Auto-generated method stub

		return asList.stream().reduce(0, Integer::sum);

	}

}
