package Task;

import java.util.Arrays;
import java.util.List;
import java.util.function.BinaryOperator;

public class T12 {
	public static void main(String[] args) {
		
		List<Integer> number = Arrays.asList(1,2,34,4);
		
		BinaryOperator<Integer> accumulator = Integer::sum;
		
		int sum= number.stream().reduce(0,accumulator);System.out.println(sum);
	}

}
