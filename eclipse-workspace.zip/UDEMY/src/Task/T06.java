package Task;

import java.util.List;

public class T06 {
	public static void main(String[] args) {
		printnumberOfCharacter(List.of("spring","apple"));
		
	}

	private static void printnumberOfCharacter(List<String> of) {
		// TODO Auto-generated method stub
		
		of.stream()
		.map(x->x+":"+x.length())
		.forEach(System.out::println);
	}

}
