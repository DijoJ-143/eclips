package Task;

import java.util.List;
import java.util.stream.Collectors;

public class T10 {

	public static void main(String[] args) {
		List<Integer> even = createListOFEvenNumbers(List.of(1, 2, 3, 4,5,6,7,8));
		
		System.out.println(even);

	}

	private static List<Integer> createListOFEvenNumbers(List<Integer> of) {
		// TODO Auto-generated method stub
		return of.stream().filter(n -> n % 2 == 0).collect(Collectors.toList());
	}

}
