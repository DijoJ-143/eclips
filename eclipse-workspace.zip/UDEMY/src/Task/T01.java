package Task;

import java.util.List;

public class T01 {
	public static void main(String[] args) {
		printOddnumber(List.of(1,2,3,4,5,6));
	}

	private static void printOddnumber(List<Integer> numbers) {
		// TODO Auto-generated method stub
		numbers.stream()
		.filter(x->x%2!=0)
		.forEach(System.out::println);
	}

}
