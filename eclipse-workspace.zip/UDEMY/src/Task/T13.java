package Task;

import java.util.List;
import java.util.function.Function;
import java.util.function.Supplier;
import java.util.stream.Collector;
import java.util.stream.Collectors;

public class T13 {

	public static void main(String[] args) {

		List<Integer> numbers = List.of(1, 2, 3, 4);

		//square
		Function<Integer, Integer> squaremapper = x -> x * x;
		Function<Integer, Integer> cubeemapper = x -> x * x *x;

		Collector<Integer, ?, List<Integer>> list = Collectors.toList();
		
		
		List<Integer> squaredNumbers = MappandCollect(numbers, squaremapper, list);
		
		List<Integer> cubeNumber = MappandCollect(numbers, cubeemapper, list);
		
		System.out.println(squaredNumbers);
		System.out.println(cubeNumber);
		
		
	}

	private static List<Integer> MappandCollect(List<Integer> numbers, Function<Integer, Integer> mapper,
			Collector<Integer, ?, List<Integer>> list) {

		return numbers.stream().map(mapper).collect(list); 
	}

}
