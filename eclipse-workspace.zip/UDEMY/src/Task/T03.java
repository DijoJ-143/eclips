package Task;

import java.util.List;

public class T03 {
	public static void main(String[] args) {
		printStringWIthSpring(List.of("spring","spring boot","angular"));
	}

	private static void printStringWIthSpring(List<String> of) {
		// TODO Auto-generated method stub
		of.stream()
		.filter(x->x.contains("spring"))
		
		.forEach(System.out::println);
	}


}
