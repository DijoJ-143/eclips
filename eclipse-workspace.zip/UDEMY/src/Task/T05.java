package Task;

import java.util.List;

public class T05 {
	public static void main(String[] args) {
		printCubeofOddnumber(List.of(1,2,3,4,9));
	}

	private static void printCubeofOddnumber(List<Integer> numbers) {
		// TODO Auto-generated method stub
		
		numbers.stream()
		.filter(n->n%2!=0)
		.map(x->x*x*x)
		.forEach(System.out::println);
		
	}

}
