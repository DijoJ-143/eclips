package Task;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;

class Course {

	private String name;
	private String category;
	private int reviewScore;
	private int noOfStudents;

	public Course(String name, String category, int reviewScore, int noOfStudents) {
		super();
		this.name = name;
		this.category = category;
		this.reviewScore = reviewScore;
		this.noOfStudents = noOfStudents;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public int getReviewScore() {
		return reviewScore;
	}

	public void setReviewScore(int reviewScore) {
		this.reviewScore = reviewScore;
	}

	public int getNoOfStudents() {
		return noOfStudents;
	}

	public void setNoOfStudents(int noOfStudents) {
		this.noOfStudents = noOfStudents;
	}

	@Override
	public String toString() {
		return "Course [name=" + name + ", category=" + category + ", reviewScore=" + reviewScore + ", noOfStudents="
				+ noOfStudents + "]";
	}

}

public class T14 {
	public static void main(String[] args) {

		List<Course> courses = List.of(

				new Course("AWS", "cloud", 98, 10000), new Course("AWS", "cloud", 97, 13000),
				new Course("Java", "Backend", 99, 20000), new Course("Java", "Backend", 96, 20000),
				new Course("API", "Microservice", 97, 12000), new Course("API", "Microservice", 98, 12000),
				new Course("Microservice", "Microservice", 94, 18000),
				new Course("Microservice", "Microservice", 95, 18000)

		);

		// predicate
		Predicate<Course> courseIsAws = (c) -> c.getName().contains("AWS");

		// any
		System.out.println(courses.stream().anyMatch(courseIsAws));

		// comparator with decending order
		Comparator<Course> comparebyStudentdecreasingOrder = Comparator.comparingInt(Course::getNoOfStudents)
				.reversed();

		courses.stream().sorted(comparebyStudentdecreasingOrder).forEach(System.out::print);

		System.out.println();
		// using then
		Comparator<Course> comparebyStudentdecreasingOrderAndReviewScore = Comparator
				.comparingInt(Course::getNoOfStudents).thenComparingInt(Course::getReviewScore).reversed();

		courses.stream().sorted(comparebyStudentdecreasingOrderAndReviewScore).forEach(System.out::print);

		// takewhile
		System.out.println();
		Comparator<Course> decreasingReview = Comparator.comparingInt(Course::getReviewScore);
		System.out.println("TAKEWHILE");
		System.out.println(courses.stream().sorted(decreasingReview).takeWhile(c -> c.getReviewScore() < 96)
				.collect(Collectors.toList()));

		// drop while

		System.out.println("DropWHILE");
		System.out.println(courses.stream().sorted(decreasingReview).dropWhile(c -> c.getReviewScore() < 96)
				.collect(Collectors.toList()));

		// min
		System.out.println("MIN");
		System.out.println(courses.stream().filter(c -> c.getReviewScore() == 0).min(decreasingReview)
				.orElse(new Course("AWS", "cloud", 98, 10000)));
		// max
		System.out.println("MAX");
		System.out.println(courses.stream().max(decreasingReview));
		// findFirst
		System.out.println("FINDFIrst");
		System.out.println(courses.stream().filter(courseIsAws).findFirst());
		// findFirst
		System.out.println("FINDANy");
		System.out.println(courses.stream().filter(courseIsAws).findAny());

		// sum with max
		System.out.print("NO : of students in aws :");
		System.out.println(courses.stream().filter(courseIsAws).mapToInt(Course::getNoOfStudents).sum());
		System.out.print(" with max value : ");
		System.out.println(courses.stream().filter(courseIsAws).mapToInt(Course::getNoOfStudents).max().orElse(0));

		//average
		System.out.print(" average NO : of students in aws :");
		System.out.println(courses.stream().filter(courseIsAws).mapToDouble(Course::getNoOfStudents).average().orElse(0));

		
		//count
		System.out.print("NO : COURSES FOUND :");
		System.out.println(courses.stream().filter(courseIsAws).mapToInt(Course::getNoOfStudents).count());
		
		
		//grouping
		System.out.println("Grouping 1");
		System.out.println(courses.stream().collect(Collectors.groupingBy(Course::getCategory)));
		System.out.println("Grouping 2");
		System.out.println(courses.stream().collect(Collectors.groupingBy(Course::getCategory,Collectors.counting())));
		System.out.println("Grouping 3");
		System.out.println(courses.stream().collect(Collectors.groupingBy(Course::getCategory,Collectors.mapping(Course::getName, Collectors.toList()))));

		
	}
}
