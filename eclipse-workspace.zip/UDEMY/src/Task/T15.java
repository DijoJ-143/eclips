package Task;

import java.math.BigInteger;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.LongStream;
import java.util.stream.Stream;

public class T15 {
	public static void main(String[] args) {
//		System.out.println(Stream.of(1, 2, 3).mapToInt(x -> x).sum());
//		System.out.println(Stream.of(1, 2, 3).count());
//
//		int[] numbers = { 1, 2, 3 };
//
//		System.out.println(Arrays.stream(numbers).sum());
//
//		System.out.println(LongStream.rangeClosed(1, 20).mapToObj(BigInteger::valueOf).reduce(BigInteger.ONE,
//				BigInteger::multiply));

//		System.out.println(Stream.of("spring", "aws").collect(Collectors.joining(" , ")));
//		System.out.println(Stream.of("spring", "aws").map(c->c.split("")).flatMap(Arrays::stream).collect(Collectors.toList()));

		List<String> course1 = List.of("aws", "boot", "aaa", "cccd");
		List<String> course2 = List.of("spring", "angular", "aws", "boot", "bbb", "dddc");

		System.out.println(course1.stream().flatMap(course -> course2.stream().map(c -> List.of(course, c)))
				.filter(l -> !(l.get(0).equals(l.get(1)))).collect(Collectors.toList()));

		// same length
		course1.stream()
				.flatMap(c1 -> course2.stream().filter(c -> c.length() == c1.length()).map(c2 -> List.of(c1, c2)))
				.filter(l->!l.get(0).equals(l.get(1)))
				.collect(Collectors.toList()).forEach(System.out::println);

	}

}
