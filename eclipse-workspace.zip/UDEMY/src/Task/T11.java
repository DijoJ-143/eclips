package Task;

import java.util.List;
import java.util.stream.Collectors;

public class T11 {
	public static void main(String[] args) {
		List<Integer> lengthOf = createListwithLength(List.of("string","spring","tyt"));
		System.out.println(lengthOf);
	}

	private static List<Integer> createListwithLength(List<String> of) {
		// TODO Auto-generated method stub
		return of.stream().map(x->x.length()).collect(Collectors.toList());
	}

}
