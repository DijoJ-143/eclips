package Task;

import java.util.List;

public class T07 {
	public static void main(String[] args) {
		System.out.println(printSumofSQuaresofNumbers(List.of(1,2,3,4)));
	}

	private static int printSumofSQuaresofNumbers(List<Integer> of) {
		// TODO Auto-generated method stub
		return of.stream()
		.map(x->x*x)
		.reduce(0,Integer::sum);
	}

}
