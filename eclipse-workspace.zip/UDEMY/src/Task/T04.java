package Task;

import java.util.List;

public class T04 {
	public static void main(String[] args) {
		printStringWIth4Letters(List.of("spring","spring boot","angular","1234","123"));
	}

	private static void printStringWIth4Letters(List<String> of) {
		// TODO Auto-generated method stub
		of.stream()
		.filter(x->x.length()>3)
		
		.forEach(System.out::println);
	}

}
