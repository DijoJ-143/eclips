package Task;

import java.util.HashMap;
import java.util.Map;

public class MAP {
	public static void main(String[] args) {
		Map<Integer, String> data = new HashMap<>();
		
		data.put(1, "dta1");
		data.put(2, "dta2");
		data.put(3, "dta3");
		
		int i=0;
		for(Map.Entry<Integer, String> entry: data.entrySet()) {
			i++;
			System.out.println(i+" : key : "+entry.getKey()+" :: value :"+entry.getValue());
			
			
		}
		
		
	}

}
