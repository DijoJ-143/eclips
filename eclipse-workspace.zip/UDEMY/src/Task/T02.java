package Task;

import java.util.List;

public class T02 {
	public static void main(String[] args) {
		printString(List.of("spring","spring boot","angular"));
	}

	private static void printString(List<String> of) {
		// TODO Auto-generated method stub
		of.stream().forEach(System.out::println);
	}

}
