package FIles;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class FileLIsts {
	public static void main(String[] args) throws IOException {
		Files.list(Paths.get(".\\src\\FIles")).forEach(System.out::println);
	}

}
