package FIles;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Arrays;

public class FileLines {

	public static void main(String[] args) throws IOException {
		Files.lines(Paths.get(System.getProperty("user.dir") + "/src/FIles/filelinetxt.txt"))
				// Convert each line to a String[]
				.map(s -> s.split(" "))
				// Flatten the Stream<String[]> to Stream<String>
				.flatMap(Arrays::stream)
				// Print each word
				.forEach(System.out::println);

	}
}