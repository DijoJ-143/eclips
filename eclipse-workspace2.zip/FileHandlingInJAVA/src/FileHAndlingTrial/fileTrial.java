package FileHAndlingTrial;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class fileTrial {
	public static void main(String[] args) {
		FileInputStream finput = null;
		FileOutputStream foutput = null;

		try {
			finput = new FileInputStream("readFromit.txt");
			foutput = new FileOutputStream("writeinto.txt");
			int c;
			while ((c = finput.read()) != -1) {
				foutput.write((char) c);

			}
			System.out.println("writing in progress.....");

		} catch (FileNotFoundException e2) {
			// TODO: handle exception
			System.out.println("invalid file name");
		} catch (IOException e) {
			// TODO: handle exception
			System.out.println("issue with Io stream");
		}

	}
}
