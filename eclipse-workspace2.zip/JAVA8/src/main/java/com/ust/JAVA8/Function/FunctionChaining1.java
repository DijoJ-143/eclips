package com.ust.JAVA8.Function;

import java.util.function.Function;

//understanding about6 function chaining
public class FunctionChaining1 {
	public static void main(String[] args) {
		// creation of fuction interfaces

		//to convert the string to uppercase
		Function<String, String> toUppercase = x -> x.toUpperCase();
		
		//to extract the first 3 letter
		Function<String, String> prefix = x-> x.substring(0,3);
		
		//print the output
		System.out.println(toUppercase.andThen(prefix).apply("dijo"));		
		

	}

}
