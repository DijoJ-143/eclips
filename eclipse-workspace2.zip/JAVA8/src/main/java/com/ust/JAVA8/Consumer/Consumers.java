package com.ust.JAVA8.Consumer;

import java.util.function.Consumer;

//understanding about consumer interface which have an method called accept
public class Consumers {
	public static void main(String[] args) {

		// creation of an consumer interface
		Consumer<Integer> c1 = x -> {
			System.out.println(x * x);
		};

		Consumer<Integer> c2 = x -> {
			System.out.println(++x + 2);
		};

		// Creating one more for the specified operation

		Consumer<Integer> result = c1.andThen(c2);

		//accept()
		result.accept(2);

	}

}
