package com.ust.JAVA8.PRedicate;

import java.util.function.Predicate;

public class AndandOrPredicate {
	public static void main(String[] args) {
		
		//predicates
		Predicate<String> StartWithD = x -> x.toLowerCase().charAt(0) == 'd';
		Predicate<String> EndWithO = x -> x.toLowerCase().charAt(x.length() - 1) == 'o';

		//and , or predicate use
		Predicate<String> names = StartWithD.and(EndWithO);
		Predicate<String> names2 = StartWithD.or(EndWithO);

		//understanding the predicates
		System.out.println(names.test("dijo"));
		System.out.println(names2.test("dijos"));

	}

}
