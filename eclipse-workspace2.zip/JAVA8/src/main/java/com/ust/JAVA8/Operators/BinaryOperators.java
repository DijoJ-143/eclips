package com.ust.JAVA8.Operators;

import java.util.function.BiFunction;
import java.util.function.BinaryOperator;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;
import java.util.function.UnaryOperator;

public class BinaryOperators {
	public static void main(String[] args) {
		// bifunction
		BiFunction<Integer, Integer, Integer> bf1 = (x, y) -> x + x;
		// consumer
		Consumer<Integer> c1 = x -> System.out.println(x);
		// suplier
		Supplier<Integer> s1 = () -> 1;

		c1.accept(bf1.apply(s1.get(), s1.get()));

		// binaryOpertor
		BinaryOperator<Integer> b1 = (x, y) -> x + y + 2;

		c1.accept(b1.apply(s1.get(), s1.get()));
	}

}
