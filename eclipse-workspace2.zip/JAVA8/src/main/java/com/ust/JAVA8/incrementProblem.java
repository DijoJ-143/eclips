package com.ust.JAVA8;

public class incrementProblem {

	public static void main(String[] args) {

		int a = 1;

		a = a++;
		System.out.println(a);
		a=a++ + a++ + a++;
		System.out.println(a);

		/*
		 * first a=a++ 
		 * rhs a++ -> a= 1 then a++
		 * lhs a= 1, also a inc goes om wrking and a=2
		 * while in lhs a=1 so a=2 is not gona to happen only the output will be of a=1
		 */

	}

}
