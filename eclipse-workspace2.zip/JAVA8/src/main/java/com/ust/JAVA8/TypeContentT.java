package com.ust.JAVA8;

public class TypeContentT<T> {
	    private T content;

	    public void setContent(T content) {
	        this.content = content;
	    }

	    public T getContent() {
	        return content;
	    }
	    
	    
	    public static void main(String[] args) {
			
	    	TypeContentT<String> t1 = new TypeContentT<>();
	    	t1.setContent("string : ");
	    	System.out.println(t1.getContent());
		}
	}



