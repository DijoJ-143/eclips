package com.ust.JAVA8.Function;

import java.util.function.Function;

//understanding conmpose()
public class FunctionCompose {
	public static void main(String[] args) {

		// creation of respective functions...
		Function<Integer, Integer> number1 = x -> x + 3;
		Function<Integer, Integer> number2 = x -> x * 3;

		// display the output using andThen()
		System.out.println(number1.andThen(number2).apply(10));
		// understanding the difference
		System.out.println(number1.compose(number2).apply(10));
	}

}
