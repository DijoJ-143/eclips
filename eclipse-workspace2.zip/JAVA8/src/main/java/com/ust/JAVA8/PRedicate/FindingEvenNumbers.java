package com.ust.JAVA8.PRedicate;

import java.util.Arrays;
import java.util.List;
import java.util.function.Predicate;

public class FindingEvenNumbers {
	// understanding about predicate

	public static void main(String[] args) {
		// creation of an predicate which accept a value and return true for even
		// numbers
		Predicate<Integer> isEven = x -> x % 2 == 0;

		// creating an list of integers
		List<Integer> numbers = Arrays.asList(1, 2, 4, 3, 6);

		for (int i : numbers) {

			if (isEven.test(i))
				System.out.println(i);
		}

	}

}
