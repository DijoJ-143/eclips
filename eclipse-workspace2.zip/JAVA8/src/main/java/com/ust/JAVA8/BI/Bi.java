package com.ust.JAVA8.BI;

import java.util.function.BiConsumer;
import java.util.function.BiFunction;
import java.util.function.BiPredicate;
import java.util.function.Supplier;

//understandi bipredicate, bifunction, biconsumer
public class Bi {
	public static void main(String[] args) {

		// bipredicate
		BiPredicate<Integer, String> biPredicate = (x, y) -> y.length() + x == 10;

		// bifunction
		BiFunction<Integer, Integer, Integer> biFuction = (x, y) -> x + y;

		// biconsumer
		BiConsumer<Integer, Integer> biConsumer = (x, y) -> System.out.println(x + y);

		// 2 supliers
		Supplier<String> suplier = () -> "dijo";
		Supplier<Integer> suplier2 = () -> 6;

//		biConsumer.accept(suplier2.get(), suplier2.get());

		if (biPredicate.test(suplier2.get(), suplier.get())) {

			biConsumer.accept(biFuction.apply(suplier2.get(), suplier2.get()),
					biFuction.apply(suplier2.get(), suplier2.get()));
		}

	}

}
