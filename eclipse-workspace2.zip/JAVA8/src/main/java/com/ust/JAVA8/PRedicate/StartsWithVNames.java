package com.ust.JAVA8.PRedicate;

import java.util.Arrays;
import java.util.List;
import java.util.function.Predicate;

public class StartsWithVNames {
	public static void main(String[] args) {
		//creation of an predicate
		Predicate<String> startsWithV = x -> x.toLowerCase().charAt(0) == 'v';

		//Creating an list
		List<String> names = Arrays.asList("vipin","vishnu","harry");
		
		//count variable for counting purpose
		int count=0;
		
		for(String s : names) {
			if(startsWithV.test(s))
				count++;
		}
		
		System.out.println("Number of words starts with v : " +count);
		
	}

}
