package com.ust.JAVA8.Consumer;

import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Supplier;

//those this class understanding the working of consumer , suplier, predicate and function
public class Supliers {
	public static void main(String[] args) {

		// predicate
		Predicate<Integer> checkIsEven = x -> x % 2 == 0;

		// Function
		Function<Integer, Integer> doubleTheNumber = x -> x * x;

		// consumer
		Consumer<Integer> printTheValue = x -> System.out.println(x);

		// supplier
		Supplier<Integer> suply = () -> 100;

		// logic
		// if the supplied one is even then only it is accepted
		if (checkIsEven.test(suply.get())) {
			// then the following doubling will happens
			printTheValue.accept(doubleTheNumber.apply(suply.get()));

		}

	}

}
