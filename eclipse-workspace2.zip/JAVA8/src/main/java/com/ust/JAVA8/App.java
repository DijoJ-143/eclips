package com.ust.JAVA8;

/**
 * Hello world!
 *
 */
public class App {
	public static void main(String[] args) {
		System.out.println("Hello World!");
		int[][] a = { { 1, 2 }, { 2, 3 } };

		for (int[] is : a) {

			for (int i : is) {
				System.out.println(i);
			}

		}
	}
}
