package com.ust.JAVA8.MethodReference;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class SortingNameUsingMethodReference {

	// student type class
	public static class Students {
		private String name;

		public Students(String name) {
			super();
			this.setName(name);
		}

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		@Override
		public String toString() {
			return this.getName();
		}

	}

	public static void main(String[] args) {

		// creating a list of names
		List<String> name = new ArrayList(List.of("dijo", "karthik", "sanyo", "amith", "sreyas", "ebin"));
		// performing a natural sorting
		name.sort(Comparator.comparing(String::length));

		// with the help of method referencing converting it into an students type
		// object
		List<Students> students = name.stream().map(Students::new).collect(Collectors.toList());

		// displaying the list
		System.out.println(students);

	}

}
