
package com.ust.JAVA8.Operators;

import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;
import java.util.function.UnaryOperator;

//understanding about unaryOperator
public class UnaryOperators {
	public static void main(String[] args) {

		// function
		Function<Integer, Integer> f1 = x -> x + x;
		// consumer
		Consumer<Integer> c1 = x -> System.out.println(x);
		// suplier
		Supplier<Integer> s1 = () -> 1;

		c1.accept(f1.apply(s1.get()));

		// unaryOpertor
		UnaryOperator<Integer> u1 = x -> x + 2;

		c1.accept(u1.apply(s1.get()));

	}
}
