package com.ust.JAVA8;

public interface Useme {
	
	String Printname(String name);

}
