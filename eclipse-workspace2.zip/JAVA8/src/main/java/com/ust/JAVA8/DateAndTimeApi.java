package com.ust.JAVA8;

import java.time.LocalDate;

public class DateAndTimeApi {
	public static void main(String[] args) {
		LocalDate todayDate =  LocalDate.now();
		System.out.println("Today :"+todayDate);
		LocalDate yesterday = todayDate.minusDays(1);
		System.out.println("yesterday: "+yesterday);
		
		if(todayDate.isAfter(yesterday))
			System.out.println("yes");
	}

}
