package com.ust.JAVA8.Function;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.function.Function;

public class FuctionS {
	// Understanding function interface
	public static void main(String[] args) {

		// creating a functional interface
		Function<String, String> subStrings = x -> {
			String s = null;

			s = x.substring(0, 3);
			return s;
		};

		Function<List<Student>, List<Student>> checkingThePrefix = li -> {

			List<Student> result = new ArrayList<>();

			for (Student s : li) {

				if ((subStrings.apply(s.getName()).equalsIgnoreCase("dij"))) {
					result.add(s);
				}
			}

			return result;
		};

		// student type objects
		Student s1 = new Student(1, "dijo");
		Student s14 = new Student(2, "dijoj");

		Student s2 = new Student(4, "Karthik");
		Student s3 = new Student(3, "Amith");

		// creating a list

		List<Student> students = Arrays.asList(s1, s2, s3, s14);

		// output for the objects having the prefix dij

		List<Student> ss1 = checkingThePrefix.apply(students);

		System.out.println(ss1);

	}

	// inner class
	private static class Student {

		// specifying the student details
		private int id;
		private String name;

		public Student(int id, String string) {
			super();
			this.setId(id);
			this.setName(string);
		}

		public int getId() {
			return id;
		}

		public void setId(int id) {
			this.id = id;
		}

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		@Override
		public String toString() {
			return "student :" + this.getName();
		}

	}

}
