package com.ust.JAVA8;

public class Use {
	public static void main(String[] args) {
		Useme u1 = (name)->name.concat(name);
		
		System.out.println(u1.Printname("gj"));
		
	}

}
