package LeetcodeDay1;

public class Fibonacci {

	public static void main(String[] args) {
		getCombinations(5);
	}

	static void getCombinations(int input) {
		// Base cases
		if (input == 0)
			System.out.print(0);
		else if (input < 0)
			System.out.println("no fibinocci");

		// Check if result is already computed
		int a = 0, b = 1;
		System.out.print(a);
		for (int i = 0; i < input; i++) {
			System.out.print(" " + b);
			int result = a + b;
			a = b;
			b = result;

		}

	}

}
