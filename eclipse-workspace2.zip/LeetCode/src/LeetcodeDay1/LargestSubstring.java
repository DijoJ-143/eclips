//package LeetcodeDay1;
//
//public class LargestSubstring {
//
//	public static void main(String[] args) {
//
//		Solution s = new Solution();
//		System.out.println(s.gcdOfStrings("ABCABC", "ABC"));
//
//	}
//
//	static class Solution {
//
////		public String gcdOfStrings(String str1, String str2) {
//			   StringBuilder sb = new StringBuilder();
//			   int count =0;
//			   boolean check=false;
//		        int minLength = Math.min(str1.length(), str2.length());
//
//		            for(int i=0;i<minLength-1;i++){
//		                if(str1.charAt(i)==str2.charAt(i)) {
//		                	sb.append(str1.charAt(i));
//		                	count=0;
//		                	check=true;
//		                }
//		                count++;
//		                
////		                if(check==true && count >1)
//		                
//		                
//		                	
//		            }
//			
//
//		}
//	}
//
//}
