package LeetcodeDay1;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class ReverseVowel {
	public static String reverseVowels(String s) {

		StringBuilder sb = new StringBuilder(s);

		Map<Integer, String> vowels = new HashMap<>();

//		use map key vcalue pair and reverse it with index

		int lefts = 0;
		int rights = s.length() - 1;

		for (int i = 0; i <= s.length() / 2; i++) {

			if (lefts < rights && isVowel(s.charAt(lefts))) {

				lefts++;
				

			}

		}

		return sb.toString();

	}

	public static boolean isVowel(char ch) {
		String vowels = "aeiouAEIOU";
		if (vowels.contains(Character.toString(ch)))
			return true;
		else
			return false;

	}

	public static void main(String[] args) {
//		System.out.println(ReverseVowel.reverseVowels("asd"));
	}

}
