package LeetcodeDay1;

import java.util.Iterator;

public class NoAdjacent {

	public static boolean canPlaceFlowers(int[] flowerbed, int n) {

	
		
	//length of array
		int len = flowerbed.length;
		for(int i=0;i<len;i++) {
			
			//checking if current one is o
			
			if(flowerbed[i]==0) {
			
		//checking leftspace
		boolean isEmptyLeft =(i==0|| flowerbed[i-1]==0);
		//checking rightside
		boolean isEmptyRightSide= (i==(len-1)||flowerbed[i+1]==0);
		
		if(isEmptyRightSide&&isEmptyLeft) {
			flowerbed[i]=1;
			n--;
		}
		
		}
		}
		return n<=0;
	}

	public static void main(String[] args) {
		NoAdjacent.canPlaceFlowers(new int[] { 1, 0, 0, 0, 1 }, 1);
	}

}
