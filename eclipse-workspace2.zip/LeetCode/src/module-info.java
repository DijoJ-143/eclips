/**
 * 
 */
/**
 * @author 269661
 *
 */
module LeetCode {
}