package Numberwise;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class Task1 {
	public static void main(String[] args) {
		
		int a[] = {2,7,11,15};
		
		Solution s = new Solution();
		
		System.out.println(	s.twoSum(a, 9));
		
		
	}

}


class Solution {
    public int[] twoSum(int[] nums, int target) {
    	
    	
    	
    	if(nums.length==1&& nums[0]==target)
    	{
    		
    		return new int[] {0} ;
    	}
    	else {
    		
    		
    	for(int i=0;i<nums.length;i++) {
    		if(nums[i]+nums[i+1]==target)
    		{
    			
    			return new int[] {i,i+1};
    			
    		}
    		
    	int output=	Arrays.stream(nums).sum();
    	
    	int del =output-target;
    	
    	//connvert array to list
    	List<Integer> li = Arrays.stream(nums).boxed().collect(Collectors.toList());
    	
    	li.remove(Integer.valueOf(del));
    	
    	return li.stream().mapToInt(Integer::intValue).toArray();
    	
    		
    	
    			
    	}
    	
    	
    	
    	
    	
    	
    	
    	return new int[] {};
    	}
        
        
    }
}