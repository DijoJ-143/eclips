package Day2;

import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class Amstrong {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a number");

		String num = sc.next();

		if (toAmstrong(num) == (Integer.parseInt(num)))
			System.out.println("Its amstrong");
		else
			System.out.println("not an amstrong ");
//		List<Integer> numb = List.of(3,7,1);
//		System.out.println(numb.stream().mapToInt(Integer::valueOf).sum());

		main(args);
	}

	public static int toAmstrong(String s) {

		return Arrays.stream(s.split("")).mapToInt(x -> (int) Math.pow(Integer.parseInt(x), s.length())).sum();

	}

}
