package Day1;

import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collector;
import java.util.stream.Collectors;

public class SumOfInteger {
	public static void main(String[] args) {

		Predicate<Integer> isEven = x -> x % 2 == 0;

		List<Integer> list = List.of(1, 2, 3, 4, 5, 6);

		Integer SumOfEvenNumbers = extracted(isEven, list);
		System.out.println(SumOfEvenNumbers);
		newWay(list);

	}

	public static Integer extracted(Predicate<Integer> predicate, List<Integer> list) {
		return list.stream().filter(predicate).reduce(0, Integer::sum);
	}

	// another way
	public static void newWay(List<Integer> list) {
		int sumOfEvenNumbers = list.stream().filter(x -> x % 2 == 0).mapToInt(Integer::intValue).sum();

		System.out.println(sumOfEvenNumbers);
	}
}
