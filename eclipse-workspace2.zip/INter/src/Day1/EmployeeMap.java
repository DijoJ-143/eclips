package Day1;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public class EmployeeMap {
	public static class Employee {
		private String id;
		private String name;
		private double salary;

		// Constructor, getters, and setters
		public Employee(String id, String name, double salary) {
			super();
			this.id = id;
			this.name = name;
			this.salary = salary;
		}

		public String getId() {
			return id;
		}

		public void setId(String id) {
			this.id = id;
		}

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public double getSalary() {
			return salary;
		}

		public void setSalary(double salary) {
			this.salary = salary;
		}

		@Override
		public String toString() {
			return "Employee [id=" + id + ", name=" + name + ", salary=" + salary + "]";
		}

	}

	public static void main(String[] args) {
		List<Employee> employees = Arrays.asList(new Employee("1", "Amith", 900), new Employee("4", "Karthik", 5000),
				new Employee("2", "Dijo", 4500), new Employee("3", "Ebin", 25000));

		Map<String, List<String>> mapSalary = employees.stream().collect(

				Collectors.groupingBy(e -> {
					if (e.getSalary() < 1000) {
						return "Less than 1000";
					} else if (e.getSalary() >= 1000 && e.getSalary() <= 5000) {
						return "1000 to 5000";
					} else {
						return "More than 5000";
					}
				}, Collectors.mapping(Employee::getName, Collectors.toList())

				));
		
		
		mapSalary.forEach((k,v)->System.out.println(k +v));

	}

}
