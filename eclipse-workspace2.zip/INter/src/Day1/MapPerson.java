package Day1;

import java.util.List;
import java.util.stream.Collectors;

public class MapPerson {

	public static class Person {
		private String name;
		private int age;

		public Person(String name, int age) {
			super();
			this.name = name;
			this.age = age;
		}

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public int getAge() {
			return age;
		}

		public void setAge(int age) {
			this.age = age;
		}

		@Override
		public String toString() {
			return "Person [name=" + name + ", age=" + age + "]";
		}

	}

	public static void main(String[] args) {
		List<Person> persons = List.of(new Person("dijo", 23), new Person("karthik", 24), new Person("Amith", 23),
				new Person("Sanyo", 23), new Person("Ebin", 20));

		System.out.println(persons.stream().collect(
				Collectors.groupingBy(Person::getAge, Collectors.mapping(Person::getName, Collectors.toList()))));
	}
	

}
