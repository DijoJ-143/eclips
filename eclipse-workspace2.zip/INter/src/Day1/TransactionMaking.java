package Day1;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public class TransactionMaking {

	public static class Transaction {
		private String id;
		private double amount;
		private String status;

		public Transaction(String id, double amount, String status) {
			super();
			this.id = id;
			this.amount = amount;
			this.status = status;
		}

		public String getId() {
			return id;
		}

		public void setId(String id) {
			this.id = id;
		}

		public double getAmount() {
			return amount;
		}

		public void setAmount(double amount) {
			this.amount = amount;
		}

		public String getStatus() {
			return status;
		}

		public void setStatus(String status) {
			this.status = status;
		}

		@Override
		public String toString() {
			return "Transaction [id=" + id + ", amount=" + amount + ", status=" + status + "]";
		}

	}

	public static void main(String[] args) {
		List<Transaction> transactions = Arrays.asList(new Transaction("1", 1000.0, "successfull") , new Transaction("2",100.0 , "failed"), new Transaction("3",1100.0 , "failed"), new Transaction("4",100.3 , "successfull"), new Transaction("2",100.0 , "failed"));
	
		Predicate<Transaction> failed = x->x.getStatus().equals("failed");
		Predicate<Transaction> Success = x->x.getStatus().equals("successfull");;
		Comparator<Transaction> desendingorder = Comparator.comparingDouble(Transaction::getAmount).reversed();
		
		
		System.out.println("1."+transactions.stream().filter(failed).collect(Collectors.toList()));
		System.out.println("2."+transactions.stream().filter(Success).sorted(desendingorder).collect(Collectors.toList()));
		System.out.println("3."+transactions.stream().filter(Success).max(Comparator.comparingDouble(Transaction::getAmount)).orElse(null));
		
		
	
	}

}
