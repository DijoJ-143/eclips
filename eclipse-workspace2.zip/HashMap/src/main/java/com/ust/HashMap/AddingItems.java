package com.ust.HashMap;

import java.util.HashMap;
//basics of Map
public class AddingItems {

	public static void main(String[] args) {
		//creating an hashmap instance
		HashMap<Integer, String> hm = new HashMap<>();
		
		//providing data 
		hm.put(1, "dijo");
		hm.put(null, "dijo");
		hm.put(null, "dijo");
		
		//displaying the map
		System.out.println(hm);
	}
}
