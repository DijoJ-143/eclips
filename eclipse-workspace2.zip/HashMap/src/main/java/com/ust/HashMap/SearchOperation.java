package com.ust.HashMap;

import java.util.HashMap;

public class SearchOperation {
	public static void main(String[] args) {
		//creating hashmap instance 
				HashMap<Integer, String> hm = new HashMap<Integer, String>();
				hm.put(1, "d");
				hm.put(2, "di");
				hm.put(3, "dj");
				hm.put(4, "o");
				
				//containsKey()
				System.out.println(hm.containsKey(1));
				System.out.println(hm.containsKey(12));
				
				System.out.println("------------------------");
				//containsValue()
				System.out.println(hm.containsValue("gy"));
				System.out.println(hm.containsValue(9));
				System.out.println(hm.containsValue("d"));
				
	}

}
