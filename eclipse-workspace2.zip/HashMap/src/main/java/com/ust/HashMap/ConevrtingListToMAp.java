package com.ust.HashMap;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class ConevrtingListToMAp {
	public static void main(String[] args) {
		HashMap<Integer, String> hm = new HashMap<>();
		hm.put(1, "aww");
		hm.put(2, "cute");

		// converting to list

		ArrayList<Map.Entry<Integer, String>> al = new ArrayList<>(hm.entrySet());

		// Converting back to HashMap
		HashMap<Integer, String> newHashMAp = new HashMap<>();
		for (Map.Entry<Integer, String> entry : al) {

			newHashMAp.put(entry.getKey(), entry.getValue());

		}
		
		System.out.println("CONVERTED ONE : "+newHashMAp);
	}

}
