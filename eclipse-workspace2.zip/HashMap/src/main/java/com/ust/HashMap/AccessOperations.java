package com.ust.HashMap;

import java.util.HashMap;

public class AccessOperations {
	public static void main(String[] args) {
		// creating hashmap instance
		HashMap<Integer, String> hm = new HashMap<Integer, String>();
		hm.put(1, "d");
		hm.put(2, "div");
		hm.put(3, "dj");
		hm.put(4, "o");

		// get()
		System.out.println(hm.get(2));

		// KeySet()
		System.out.println("KEYSET: " + hm.keySet());

		// Values()
		System.out.println("VALUES: " + hm.values());

		// entrySet()
		System.out.println("ENTRYSET :" + hm.entrySet());

	}

}
