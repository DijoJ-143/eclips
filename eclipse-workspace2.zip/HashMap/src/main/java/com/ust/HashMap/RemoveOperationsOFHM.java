package com.ust.HashMap;

import java.util.HashMap;

//performing alll the hash map operations
public class RemoveOperationsOFHM {
	public static void main(String[] args) {
		
		//creating hashmap instance 
		HashMap<Integer, String> hm = new HashMap<Integer, String>();
		hm.put(1, "d");
		hm.put(2, "di");
		hm.put(3, "dj");
		hm.put(4, "o");
		
		System.out.println("before removing:"+hm);
		//remove(object key)
		hm.remove(1);
		System.out.println("After removing:"+hm);
		
		//clear()
		hm.clear();
		System.out.println("After clear:"+hm);
		
		
	}
}
