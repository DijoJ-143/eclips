package com.ust.HashMap;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class ConvertingMapToLIst {
	public static void main(String[] args) {
		HashMap<Integer, String> hm = new HashMap<>();
		hm.put(1,"aww");
		hm.put(2, "cute");
		
		//converting to list
		
		ArrayList<Map.Entry<Integer, String>> al = new ArrayList<>(hm.entrySet());
		System.out.println("HM"+hm);
		System.out.println("AL"+al);
		
	}

}
