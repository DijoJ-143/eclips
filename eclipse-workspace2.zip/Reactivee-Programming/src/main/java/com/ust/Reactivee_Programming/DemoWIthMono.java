
package com.ust.Reactivee_Programming;



import org.reactivestreams.Subscriber;
import org.reactivestreams.Subscription;

import reactor.core.CoreSubscriber;
import reactor.core.publisher.Mono;

public class DemoWIthMono {

	
	@SuppressWarnings("unchecked")
	public static void main(String[] args) {
		 Mono<String> monoPublisher =  Mono.just("data1");
		 monoPublisher.subscribe(new CoreSubscriber<String>() {

			@Override
			public void onSubscribe(Subscription arg0) {
				// TODO Auto-generated method stub
				
				
			}

			
			 
		} );

	}

}
