package com.ust.revise.ReviseConcepts.HotelManagementSystem;

public class Guest {

	// properties
	private String name;
	private int age;
	private int daysStayed;

	// constructor
	public Guest(String name, int age, int daysStayed) {
		super();
		this.name = name;
		this.age = age;
		this.daysStayed = daysStayed;
	}

	// getter and setter
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public int getDaysStayed() {
		return daysStayed;
	}

	public void setDaysStayed(int daysStayed) {
		this.daysStayed = daysStayed;
	}
	
	
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "Guest :[ "+name+" , "+age+" , "+daysStayed+" ]";
	}

}
