package com.ust.revise.ReviseConcepts.HotelManagementSystem;

import java.util.List;
import java.util.Scanner;

public class HotelmanagementMain {

	public static void main(String[] args) {
		// creating hotel object
		Hotel hotel = new Hotel();
		// adding rooms
		hotel.addRoom(new Room(101, 1000.0, true, "Normal"));
		hotel.addRoom(new Room(201, 8000.0, true, "Deluxe"));
		hotel.addRoom(new Room(301, 10000.0, true, "Luxury"));

		// creating object for hotel management passing the hotel with rooms

		HotelManagement management = new HotelManagement(hotel);

		// -------------------------MAIN WORKING--------------------------------------

		System.out.println("Welcome To Hotel Info Desk \n Choose an option");
		Scanner sc = new Scanner(System.in);

		while (true) {
			System.out.println("----------------------\n");
			System.out.println("1. Check available rooms");
			System.out.println("2. Check room price");
			System.out.println("3. Book a room");
			System.out.println("4. Exit\n");

			int choice = sc.nextInt();
			sc.nextLine();// consume leftover new line (important # got error due to avoiding it)

			switch (choice) {
			case 1: {
				List<Room> result = management.filterBy(Room::isAvailable);
				result.forEach(System.out::println);

				break;

			}
			case 2: {
				System.out.println("Enter room type (Normal, Deluxe, Luxury):");
				String roomType = sc.nextLine();
				List<Room> roomsByType = management.filterBy(r -> r.getType().equalsIgnoreCase(roomType));

				if (!(roomsByType.isEmpty())) {
					roomsByType.forEach(room -> System.out.println("Price : " + room.getPrice()));

				} else {
					System.out.println("No rooms of type " + roomType + " found.");
				}
				break;

			}

			case 3: {

				System.out.println("Enter room type (Normal, Deluxe, Luxury):");
				String roomType = sc.nextLine();

				Room roomTobook = hotel.listAllRooms().stream()
						.filter(r -> r.getType().equalsIgnoreCase(roomType) && r.isAvailable()).findFirst()
						.orElse(null);

				if (roomTobook != null) {
					roomTobook.bookRoom();
					System.out.println("Booking successfull\n room number :" + roomTobook.getRoomNumber() + " type : "
							+ roomTobook.getType());
				}
				else
					System.out.println("Room is not available ❌");

				break;
			}

			case 4: {
				System.err.println("EXITING");
				sc.close();
				return;

			}
			default:
				throw new IllegalArgumentException("Unexpected value: " + choice);
			}
		}

	}

}
