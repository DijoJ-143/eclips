package com.ust.revise.ReviseConcepts.HotelManagementSystem;

import java.util.ArrayList;
import java.util.List;

public class Hotel {

	// properties
	private List<Room> rooms;

	// constructor
	public Hotel() {
		rooms = new ArrayList<>();
	}
	
	//adding room
	public void addRoom(Room r) {
		rooms.add(r);
	}
	
	//list all rooms
	public List<Room> listAllRooms(){
		return this.rooms;
	}

}
