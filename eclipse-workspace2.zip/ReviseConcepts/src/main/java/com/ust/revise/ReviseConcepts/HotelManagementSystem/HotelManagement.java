package com.ust.revise.ReviseConcepts.HotelManagementSystem;

import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public class HotelManagement {

	// property
	private Hotel hotel;

	// constructor
	public HotelManagement(Hotel hotel) {
		this.hotel = hotel;
	}

	// filter method
	public List<Room> filterBy(Predicate<Room> predicate) {
		return hotel.listAllRooms().stream().filter(predicate).collect(Collectors.toList());
	}

}
