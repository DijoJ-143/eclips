package com.ust.revise.ReviseConcepts.HotelManagementSystem;

public class Room {

	// properties
	private int roomNumber;
	private double price;
	private boolean isAvailable;
	private String type;

	// constructor
	public Room(int roomNumber, double price, boolean isAvailable, String type) {
		super();
		this.roomNumber = roomNumber;
		this.price = price;
		this.isAvailable = isAvailable;
		this.type = type;
	}

	// Getter and setter

	public int getRoomNumber() {
		return roomNumber;
	}

	public void setRoomNumber(int roomNumber) {
		this.roomNumber = roomNumber;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public boolean isAvailable() {
		return isAvailable;
	}

	public void setAvailable(boolean isAvailable) {
		this.isAvailable = isAvailable;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	// making it as unavilable if booked
	public void bookRoom() {
		isAvailable = false; // Mark as booked
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "Room Info \n RoomNumber : " + roomNumber + " [  Available : " + isAvailable + " || Type : " + type + " ]";
	}

}
