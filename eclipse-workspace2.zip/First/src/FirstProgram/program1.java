package FirstProgram;

import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.List;

public class program1 {
	public static void main(String[] args) {
		System.out.println("Hello world");
		System.out.println("Hai world");
		
		List<Integer> li = Arrays.asList(1,2);
		System.out.println(li.size());
		
		int[] a = {1,2,3,4};
		System.out.println(a.length);
		
	}

}
