package CustomException;

public class ElligibeForParticipation extends Exception {

	/*
	 * class for elligible members
	 */
	@Override
	public String getMessage() {
		// TODO Auto-generated method stub
		return "Elligibe for  participation in election";
	}

}
