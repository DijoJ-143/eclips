package CustomException;

import java.util.Scanner;

public class Election {
	
	/*method which take age as input and throws the exceptions
	 */
	public void status(int age) throws UnderAge, ElligibeForParticipation {
		if (age <= 17)
			throw new UnderAge();
		else
			throw new ElligibeForParticipation();
	}

	public static void main(String[] args) {
		// instance of Election type
		Election election = new Election();

		// input data
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter your age");
		int age = sc.nextInt();

		// logic
		try {
			election.status(age);
		} catch (UnderAge e1) {
			// TODO: handle exception
			System.out.println("------------STATUS--------------");
			System.err.println(e1.getMessage());
			System.out.println("you need to wait " + (18 - age) + " more years");

		} catch (ElligibeForParticipation e1) {
			// TODO: handle exception
			System.out.println("------------STATUS--------------");
			System.out.println(e1.getMessage());

		}
	}
}
