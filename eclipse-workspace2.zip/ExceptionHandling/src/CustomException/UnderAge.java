package CustomException;

public class UnderAge extends Exception {

	// creating a class called UnderAge and made it subclass of throwable type and
	// override the toString method

	@Override
	public String getMessage() {
		// TODO Auto-generated method stub
		return "Not elligible for ellection";
	}

}
