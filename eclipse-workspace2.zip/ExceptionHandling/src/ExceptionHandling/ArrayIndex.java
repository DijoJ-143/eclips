ackage ExceptionHandling;

public class ArrayIndex {

	// method to fetch a patticular element from the array using index
	//method throws an Exception if an ubnormal condition arise 

	static void index(int[] a, int index) throws ArrayIndexOutOfBoundsException {
		System.out.println(a[index]);
	}

	public static void main(String[] args) {

		//intializing an integer array with numbers
		int a[] = { 1, 2, 3, 4, 6 };
		try {
			index(a, 8);

		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("******PRINT STACK TRACE*******");
			e.printStackTrace();
		}

	}

}
