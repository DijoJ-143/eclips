package ExceptionTrial;

public class TryCatchwithRandommsg {
	// To understand about exception handling

	public static void main(String[] args) {
		try {
			System.out.println(10 / 0);
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("may be done with 0");
			System.out.println(e.getMessage());
		}
	}

}
