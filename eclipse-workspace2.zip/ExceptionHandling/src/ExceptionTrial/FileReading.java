package ExceptionTrial;

import java.io.FileReader;
import java.io.IOException;

public class FileReading {
	// reading file with the help of class called FileReader
	// Throws keyword in prior to throw an exception
	public void readFile(String filepath) throws IOException {

		// fileReader is set to null
		FileReader fileReader = null;

		try {
			fileReader = new FileReader(filepath);

			int character = 0;

			// if -1 returns that its the end
			while ((character = fileReader.read()) != -1) {
				System.out.println((char) character);
			}
		}
		// have to execute at last
		finally {

			if (fileReader != null)
				fileReader.close();
		}

	}

	public static void main(String[] args) {

		// creting an instance of the classs FileReading
		FileReading fr = new FileReading();

		try {
			fr.readFile("example.txt");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
		}

	}

}
