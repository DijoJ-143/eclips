package LinkedList;

import java.util.LinkedList;

public class L1Clone {
	public static void main(String[] args) {
		LinkedList<Integer> ll = new LinkedList<>();
		ll.add(20);
		ll.add(10);
		ll.offer(110);
		
		
		LinkedList<Integer> cloneddList = (LinkedList<Integer>) ll.clone();
		System.out.println("cloned: " +cloneddList);
		
		if(cloneddList.contains(10))
			System.out.println(cloneddList.indexOf(10)+1);
		
		
	}

}
