package FunctionalInterface2;

import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.Period;

public class LOcalDateAndTimeDuration {

	public static void main(String[] args) {

		// localDte
		LocalDate ld = LocalDate.now();

		LocalDate ld2dAYS = ld.plus(Period.ofDays(2));
		int DaysDifference = Period.between(ld, ld2dAYS).getDays();
		System.out.println("--Days-->" + DaysDifference);

		// initialTime
		LocalTime lt = LocalTime.of(6, 30, 30);

//		System.out.println(lt.plus(Duration.ofSeconds(30)));

		int timeDifference = (int) Duration.between(lt, LocalTime.now()).getSeconds();
		System.out.println("----Second-->" + timeDifference);

		//we can also use ChronoUnits
	}

}
