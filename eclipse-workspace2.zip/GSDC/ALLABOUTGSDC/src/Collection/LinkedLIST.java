package Collection;

import java.util.Iterator;
import java.util.LinkedList;

public class LinkedLIST {
	
	public static void main(String[] args) {
		
		LinkedList<String> li = new LinkedList<>();
		
		//add
		li.add("heheheh");
		
		System.out.println(li);
		
		//addFirst
		li.addFirst("hohoh");
		
		li.addLast("rrrrr");
		System.out.println(li);
		
		//set
		li.set(0, "TOM");
		System.out.println(li);
		
		//remove
		li.removeFirst();
		System.out.println(li);
		
		//for
		System.out.println("--------FOR LOOP");
		for(int i=0;i<li.size();i++) {
			System.out.println(li.get(i));
		}
		
		
		System.out.println("--------ADVANCED FOR LOOP");
		for(String s: li) {
			System.out.println(s);
		}
		
		
		System.out.println("------------Iterator");
		
		Iterator<String> iterator=  li.iterator();
		while(iterator.hasNext()) {
			System.out.println(iterator.next());
		}
		
		
		System.out.println("------------------while");
		int num=0;
		
		while(li.size()>num) {
			System.out.println(li.get(num));
			num++;
		}
		
	}

}
