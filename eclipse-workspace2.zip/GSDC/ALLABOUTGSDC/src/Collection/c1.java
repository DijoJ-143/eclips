package Collection;

import java.util.List;

public class c1 {
	public static void main(String[] args) {
		
		Employee e1 = new Employee("ddd");
		Employee e2 = new Employee("ddd");
		Employee e3 = new Employee("ddd");
		
		
		List<Employee> list = List.of(e1,e2,e3);
		System.out.println(list);
	}

}

class Employee {
	private String name;

	public Employee(String name) {
		super();
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public String toString() {
		return "Employee [name=" + name + "]";
	}
	
	

}
