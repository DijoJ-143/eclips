package Thread;

class ThreadsClass implements Runnable {

	@Override
	public void run() {
		// TODO Auto-generated method stub
		for (int i = 0; i < 10; i++) {
			System.out.println("1." + i);
		}
	}

}

public class MyTask{
	
	public static void main(String[] args) throws InterruptedException {
		
		
Runnable r1 = new ThreadsClass();
		
		Thread t = new Thread(r1);
		t.start();
		for (int i = 0; i < 10; i++) {
			System.out.println("2." + i);
			
		}
		
		
		
		
	}
	
	

}
