package Thread;

class Printer {

	synchronized void  printFile(int noOfTime, String fileName) {
		for (int i = 0; i < noOfTime; i++) {

			System.out.println(fileName + " : " + i);

		}
	}

}

class MyThread extends Thread {
	Printer pri;

	MyThread(Printer p) {

		this.pri = p;

	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		pri.printFile(10, "MyThread.pdf");
	}

}



class YourThread extends Thread {
	Printer pri;

	YourThread(Printer p) {

		this.pri = p;

	}

	@Override
	public void run() {
		
		synchronized (pri) {
			pri.printFile(10, "YourThread.pdf");
			
		}
		// TODO Auto-generated method stub
	}

}


public class SynchronizedPrinter {

	public static void main(String[] args) throws InterruptedException {
		
		Printer p = new Printer();
		
		MyThread mt = new MyThread(p);
		
		YourThread yt = new YourThread(p);
		
		mt.start();
	
		yt.start();
		
		

	}

}
