package OPtionalClass;

import java.util.Optional;

public class O1 {
	// null pointer exception
	// util package::helps in null check and NUll pointer Exception
	// option as a single valued container which either contain value or empty
	// static method to create optional:: of,empty.ofNullable

	public static void main(String[] args) {

		String email1 = "dijoj143kasjdk.com";
		String email2 = null;
		Optional<String> ofNullable1 = Optional.ofNullable(email1);
		Optional<String> ofNullable2 = Optional.ofNullable(email2);

		System.out.println(ofNullable1);

		// get, ispresent
		if (ofNullable1.isPresent()) {
			System.out.println(ofNullable1.get());
		} else
			System.out.println("No value ");

		// .orElse: String
		System.out.println(ofNullable2.orElse("default@gmail.com"));

		// orElseGet:uses suplier
		System.out.println(ofNullable2.orElseGet(()->"defaultonorElsseGEt"));

		
		//orElseThrow
//		System.out.println(ofNullable2.orElseThrow(()->new IllegalArgumentException(" Exception::NO value to be displayed")));
	
		//ifPresent
		Optional<String> gender = Optional.of(" male");
		
		gender.ifPresent((s)->System.out.println("Value present : " +gender.get()));
		
		//map and filter
		gender.map(String::trim).filter(s->s.equals("male")).ifPresent(System.out::println);
	
	}

}
