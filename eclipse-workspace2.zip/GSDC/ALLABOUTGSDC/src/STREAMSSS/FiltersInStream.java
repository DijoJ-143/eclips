package STREAMSSS;

import java.util.Comparator;
import java.util.List;

public class FiltersInStream {
	class Product {
		int size;

		public Product(int size) {
			super();
			this.size = size;
		}

		public int getSize() {
			return size;
		}

		public void setSize(int size) {
			this.size = size;
		}

		@Override
		public String toString() {
			return "Product [size=" + size + "]";
		}

	}

	public static void main(String[] args) {

		FiltersInStream f1 = new FiltersInStream();

		List<Product> list = List.of(f1.new Product(6), f1.new Product(2), f1.new Product(3), f1.new Product(4));

//		list.stream().sorted((p1,p2)->p1.getSize()-p2.getSize()).forEach(System.out::println);

		list.stream().sorted(Comparator.comparingInt(Product::getSize)).forEach(System.out::println);

		System.out.println("COUNT--> "+list.stream().count());
//		list.stream().max((x,y)->x-y).get();
		System.out.println("MAX VALUE---> "+list.stream().max(Comparator.comparing(Product::getSize)).get());
	}

}
