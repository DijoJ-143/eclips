package STREAMSSS;

import java.util.stream.Stream;

public class CreationOfStreams {
	public static void main(String[] args) {
		
		//stream.of
		Stream.of("a","b").forEach(System.out::println);
		//collection.stream
		//list.stream
		//set.stream()
		//Arrays.stream(array);
	}

}
