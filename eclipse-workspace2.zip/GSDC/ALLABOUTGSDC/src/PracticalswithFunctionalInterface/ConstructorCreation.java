package PracticalswithFunctionalInterface;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.function.BiFunction;

public class ConstructorCreation {

	static class Employee {

		int age;
		String name;

		public Employee(int age, String name) {
			super();
			this.age = age;
			this.name = name;
		}

		@Override
		public String toString() {
			return "Employee [age=" + age + ", name=" + name + "]";
		}
		
		

	}

	public static void main(String[] args) {
		BiFunction<Integer, String, Employee> ec = Employee::new;
		Scanner sc = new Scanner(System.in);
		
		
		
		Employee e1 = ec.apply(12, "dijo");
		System.out.println(e1);
		
		List< Employee> list = new ArrayList<>();
		
		for(int i =0;i<10;i++) {
			
			list.add(ec.apply(i+10, sc.next()));
			
		}
		
		
		list.forEach(System.out::println);
	}

}
