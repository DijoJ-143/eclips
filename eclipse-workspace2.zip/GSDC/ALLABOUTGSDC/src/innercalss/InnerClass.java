package innercalss;

public class InnerClass {

	public static void main(String[] args) {
		Animal aobject = new Animal();
		Animal.Dog dog = aobject.new Dog();

		Cat c = new Cat();

		aobject.makeSound(dog);
		aobject.makeSound(c);

	}

}

interface SoundPicker {
	String soundpicker();
}

class Animal {

	class Dog implements SoundPicker {

		@Override
		public String soundpicker() {
			// TODO Auto-generated method stub
			return "bow bow ";

		}
	}

	public void makeSound(SoundPicker picker) {
		System.out.println(picker.soundpicker());
	}
}

class Cat implements SoundPicker {

	@Override
	public String soundpicker() {
		// TODO Auto-generated method stub
		return "meow meow";
	}

}
