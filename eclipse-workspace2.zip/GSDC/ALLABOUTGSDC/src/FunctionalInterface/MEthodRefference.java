package FunctionalInterface;

import java.util.function.BiFunction;

public class MEthodRefference {
	
	static int addition(int a, int b) {
		return a+b;
	}
	
	//constructor-: className::new
	//class::staticName
	//obj::instancename
	//class::instanceNmae
	public static void main(String[] args) {
		
		BiFunction<Integer, Integer, Integer> add = MEthodRefference::addition;
		System.out.println(add.apply(1, 2));
		
	}

}

