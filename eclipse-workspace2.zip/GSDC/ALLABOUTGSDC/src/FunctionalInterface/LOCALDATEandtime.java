package FunctionalInterface;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;

public class LOCALDATEandtime {
	// localDateTime.now
	// localDateTime.of(2015,Month.feb..,20,06,30)-> 20 feb 2015 ,06:30
	// localDateTime.parse("2015-02-20T06:30:00")->yyyy-mm-ddTime hh:mm:ss
	// .plusDays(1)
	// .minusHours(2)
	// .getMonth()

	public static void main(String[] args) {
		LocalDateTime l1 = LocalDateTime.now();
		System.out.println(l1);
		
		
		LocalDate localdate = l1.toLocalDate();
		LocalTime localtime = l1.toLocalTime();
		
		System.out.println(localdate);
		System.out.println(localtime);
	}

}
