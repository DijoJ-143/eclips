package FunctionalInterface;

@FunctionalInterface
public interface Print {
	
	public void ReadndPrint(String s);

}
