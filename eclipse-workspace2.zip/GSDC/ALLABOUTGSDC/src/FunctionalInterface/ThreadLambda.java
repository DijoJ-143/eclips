package FunctionalInterface;

public class ThreadLambda {
	
	public static void main(String[] args) {
		Runnable r1 = ()->{
			System.out.println(" thread started ....");
		};
		
		
		Thread t1 = new Thread(r1);
		t1.start();
		
		Thread t2 = new Thread(()->System.out.println("thread t2 started"));
		t2.start();
		
	}

}
