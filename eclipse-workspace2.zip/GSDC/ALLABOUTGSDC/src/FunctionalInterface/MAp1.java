package FunctionalInterface;

import java.util.HashMap;

public class MAp1 {
	public static void main(String[] args) {
		HashMap<Integer, String> hm = new HashMap<>();
		hm.put(1, "set");
		hm.put(2, "set");
		hm.put(3, "set");
		
		hm.forEach((key,value)->{
			System.out.println( key+" | "+value);
		});
	}

}
