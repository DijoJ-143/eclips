package FunctionalInterface;

import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;

public class f1 {
	
	
	public static void main(String[] args) {
	
		Print p1 = (String s) -> {
			System.out.println(s);
		};
		
		p1.ReadndPrint("Dijo");
		
		//function: apply 
		
		
		Function<String, Integer> length = (String s)-> s.length();
		
		//accept but not return anything
		Consumer<Integer> cons = (Integer i)->{
			System.out.println(i);
		};
		
		cons.accept(20);
		
		//supplier
		Supplier<Integer> supplier = ()->4;
		
		System.out.println(length.apply("dijo").equals(supplier.get())?"equal":"not equal");
		
		//multiple ternary
		 int a = 10;
	        int b = 20;

	        // Using the ternary operator with System.out.println
	        String result = (a > b) ? ("a is greater than b") : ("b is greater than or equal to a");

	        // The result value will be printed here
	        System.out.println("The result is: " + result);

	}

	

	

}
