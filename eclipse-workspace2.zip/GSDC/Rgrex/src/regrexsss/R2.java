package regrexsss;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class R2 {

	public static void main(String[] args) {
		Pattern p1 = Pattern.compile("\\w+");
		Matcher m1 = p1.matcher("@3wer4@we33asdafasf9ad0sfa09f0a90f9afasfASF()A(SF)ASF()AFasfadas+++DF@R@#R@#$#$#RWRG#G@EG%UB^%^FU$HD%T");
		
		System.out.println("WORDS ONLY ");
		int i =1;
		while(m1.find()) {
			
			System.out.println((i++) +" ---> " + m1.group());
		}
	}
}
