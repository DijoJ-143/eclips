package regrexsss;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class R3 {
	public static void main(String[] args) {
		System.out.println("EMAIL REGREX");
		
		Pattern p1= Pattern.compile("[\\w+]@gmail.com");
		Matcher m1 = p1.matcher("dijo143_@gmail.com");
		
		
		int i=1;
		while(m1.find()) {
			
			System.out.println(i++ +" --> "+ m1.group());
			
		}
		
	}
}
