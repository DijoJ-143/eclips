package regrexsss;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ValidatingUsers {
	public static void main(String[] args) {
		
		
		List<User> listofUsers = List.of(new User("dijo@",23),new User("dijo11", 23),new User("hyro", 236),new User("vipro", 24));
		
		Pattern p1 = Pattern.compile("Name=(?<name>\\w+) Age=(?<age>\\d{2})");
		Matcher m1 = p1.matcher(listofUsers.toString());
		
		
		int i = 0;
		while (m1.find()) {
			i++;
		System.out.println("Valid : USER-NAME ::" +m1.group("name")+"  USER-AGE:: "+ m1.group("age"));
			
		}
		
		System.out.println("OUT OF "+listofUsers.size()+" : : "+i+" is Valid");
	}

}
