package regrexsss;

import java.util.Scanner;
import java.util.regex.MatchResult;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Stream;

public class MatchEmail {
	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		System.out.println("enter the email to check the validation");
		String Email = sc.next();

//		   // Define a simple email regex pattern
//        Pattern pattern = Pattern.compile("^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$");
//        
//        Matcher matcher = pattern.matcher(email);
		//"word boundary" (\b) and "word character" (\w)
		// asd123@gmail.com
		Pattern p = Pattern.compile("\\b\\w+@\\w+\\.com\\b");
		Matcher m = p.matcher(Email);

		Stream<String> isValid = m.results().map(MatchResult::group);

		String result = isValid.count() == 0 ? "not valid" : "valid";
		System.out.println(result);

	}

}
