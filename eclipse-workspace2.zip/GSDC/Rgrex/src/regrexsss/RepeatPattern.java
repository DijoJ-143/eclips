package regrexsss;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RepeatPattern {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);

		System.out.println("Enter the Pattern you want to match");

		Pattern p1 = Pattern.compile("(" + sc.next() + ")");

		System.out.println("Enter the word you want to match with the pattern");
		Matcher m1 = p1.matcher(sc.next());

		int i = 1;
		while (m1.find()) {

			System.out.println(i++ + " ---> " + m1.group());

		}

	}

}
