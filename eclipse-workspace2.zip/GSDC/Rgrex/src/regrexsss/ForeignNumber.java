package regrexsss;

import java.util.regex.MatchResult;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ForeignNumber {
	public static void main(String[] args) {
		
		
		//results :: stream
		
		String input = "(123) 456-7890";

		// Define the pattern for phone numbers
		Pattern pattern = Pattern.compile("\\(\\d{3}\\) \\d{3}-\\d{4}");

		// Create a matcher for the input string
		Matcher matcher = pattern.matcher(input);
		
		matcher.results().forEach(m-> System.out.println("Matched:: "+m.group()));
	}

}
