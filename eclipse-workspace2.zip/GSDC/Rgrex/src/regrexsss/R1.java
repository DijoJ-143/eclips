package regrexsss;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class R1 {
	
	
	
	
	public static void main(String[] args) {
		
		//printf for to return the value 
		if(System.out.printf("hellow world\n")==null) {}
		
		//gives word
		
//		Pattern p1 = Pattern.compile("\\d+");  
		//gives charcter
		Pattern p1 = Pattern.compile("[0-9]");
		Matcher m1 = p1.matcher("123aaa2334");
		
		while(m1.find()) {
			System.out.println(m1.group());
		}
		
	}

}
