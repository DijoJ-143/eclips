package j1;

/**
 * This class represents a person with a name and an age.
 */
public class Person {
    private String name;
    private int age;

    /**
     * Constructor to initialize a person object with a name and age.
     * @param name The name of the person.
     * @param age The age of the person.
     */
    public Person(String name, int age) {
        this.name = name;
        this.age = age;
    }

    /**
     * Gets the name of the person.
     * @return The name of the person.
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the name of the person.
     * @param name The name to set.
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Gets the age of the person.
     * @return The age of the person.
     */
    public int getAge() {
        return age;
    }

    /**
     * Sets the age of the person.
     * @param age The age to set.
     * @throws IllegalArgumentException if the age is negative.
     */
    public void setAge(int age) throws IllegalArgumentException {
        if (age < 0) {
            throw new IllegalArgumentException("Age cannot be negative.");
        }
        this.age = age;
    }
    
    
    Person [] p = new  Person[2];
}

