package DuplicatingObjects;

public class Box {

	int width;
	int height;

	Box(int width, int height) {

		this.width = width;
		this.height = height+1;

	}

	Box(Box b) {
		this.width = b.width;
		this.height = b.height;
	}

	Box duplicate() {

//		for 1st constructor
//		return new Box(this.width,this.height);

		// for 2nd constructor
//		return new Box(this);
		return new Box(width,height);
	}

	@Override
	public String toString() {
		return "Box [width=" + width + ", height=" + height + "]";
	}

}
