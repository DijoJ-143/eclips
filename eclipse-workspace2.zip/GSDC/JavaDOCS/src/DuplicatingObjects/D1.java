package DuplicatingObjects;

public class D1 {
	public static void main(String[] args) {
		
		Box b1 = new Box(100, 2);
		Box b2 = b1.duplicate();
		System.out.println(b1);
		System.out.println(b2);
		
	}

}
