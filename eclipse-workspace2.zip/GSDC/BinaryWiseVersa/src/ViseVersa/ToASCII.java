package ViseVersa;

import java.util.Scanner;

public class ToASCII {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("ENTER A BINARY STRING (multiple of 8 bits)");
        String data = sc.next();  // Read binary string input
        StringBuffer sb = new StringBuffer();

        // Ensure the input string length is a multiple of 8
        if (data.length() % 8 != 0) {
            System.out.println("Invalid input! The binary string length must be a multiple of 8.");
            return;  // Exit the program if input is invalid
        }

        // Loop through the binary string in chunks of 8 bits
        for (int i = 0; i < data.length(); i += 8) {
            // Take 8 bits, convert to decimal, and then to ASCII character
            String byteString = data.substring(i, i + 8);
            int decimal = Integer.parseInt(byteString, 2);  // Convert binary to decimal
            sb.append((char) decimal);  // Convert decimal to ASCII character and append
        }

        // Output the resulting ASCII string
        System.out.println("The ASCII value: " + sb);
    }
}
