package ViseVersa;

import java.util.Scanner;

public class ToBinary {
	
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("ENTER A STRING");
		String data = sc.next();
		StringBuffer sb = new StringBuffer();
		
		
		for(char c:data.toCharArray()) {
			
			 
			sb.append( String.format("%8s", Integer.toBinaryString(c)).replace(' ', '0'));
			
			
		}
		
		
		System.out.println("The \"BINARY\" value : " +sb);
		
	}

}

