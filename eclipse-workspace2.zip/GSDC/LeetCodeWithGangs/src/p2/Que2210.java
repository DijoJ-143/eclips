package p2;

import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

public class Que2210 {

	public static void main(String[] args) {

		int[] num = { 2, 4, 1, 1, 6, 5 };
//		System.out.println(Solution.countHillValley(num));
		
		Set<Integer> s1 = new LinkedHashSet(Arrays.asList(Arrays.stream(num).boxed().toArray(Integer[]::new)));
		 int[] nums = s1.stream().mapToInt(Integer::intValue).toArray();
		 int count =0;
		
		for(int i =1;i<nums.length-1;i++) {
			
			if (nums[i] > nums[i - 1] && nums[i] > nums[i + 1])
				count++;
			else if (nums[i] < nums[i - 1] && nums[i] < nums[i + 1]) {
				count++;
			}
			

			
			}
		
		}
		 
		 
		 
		 
		 
		 
		 
		 
		 
		 
		 
		 
		 
		 
		//use linked hashsdedt for maintainning order
		
//		Set s1 = new LinkedHashSet(Arrays.asList(8,1,3,2,3,4,5,1,2));
//		
//		s1.stream().forEach(System.out::println);
		
		
	}

//	static class Solution {
//		static int count = 0;
//
//		public static int countHillValley(int[] nums) {
//			
//			
//			Set<Integer> set = new HashSet(Arrays.asList(nums));
//			for(Integer i :set) {
//				System.out.println(i);
//			}
//
//			for (int i = 1; i < nums.length - 1; i++) {
//
//				if (nums[i] > nums[i - 1] && nums[i] > nums[i + 1])
//					count++;
//				else if (nums[i] == nums[i + 1]) {
//					if (nums[i] > nums[i - 1] && nums[i] > nums[i + 2])
//						count++;
//
//				} else if (nums[i] == nums[i - 1]) {
//					if (nums[i] > nums[i - 2] && nums[i] > nums[i + 1])
//						count++;
//
//				}
//
//			}
//
//			return count;
//
//		}
//	}

}
