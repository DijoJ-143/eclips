//package p2;
//
//import java.util.ArrayList;
//import java.util.Collections;
//import java.util.HashMap;
//import java.util.List;
//
//public class Que1370 {
//	public static void main(String[] args) {
//		Solution s = new Solution();
//
//		System.out.println(s.sortString("aaaabbbbcccc"));
//		System.out.println(s.sortString("rat"));
//
//	}
//
//}
//
////class Solution {
////	public String sortString(String s) {
////
////		Set set = new HashSet<>();
////		HashMap<Character, Integer> hm = new HashMap<>();
////
////		for (char c : s.toCharArray()) {
////
////			set.add(c);
////
////			hm.put(c, hm.getOrDefault(c, 0) + 1);
////		}
////
////		List<Character> list = new ArrayList<>(set);
////		System.out.println(list);
////		
////		for (char key : hm.keySet()) {
////			System.out.println(key + ": " + hm.get(key));
////		}
////
////		StringBuffer sb = new StringBuffer();
////		while (!hm.isEmpty()) {
//
//			for (int i = 0; i < list.size(); i++) {
//				char c = list.get(i);
//				if (hm.containsKey(c)) {
//					sb.append(c);
//					hm.put(c, hm.get(c) - 1);
//					if (hm.get(c) == 0) {
//						hm.remove(c);
//					}
//				}
//			}
//
//			for (int i = list.size() - 1; i >= 0; i--) {
//				char c = list.get(i);
//				if (hm.containsKey(c)) {
//					sb.append(c);
//					hm.put(c, hm.get(c) - 1);
//					if (hm.get(c) == 0) {
//						hm.remove(c);
//					}
//				}
//			}
//
//		}
//		return sb.toString();
////	}
////}
//
//class Solution {
//	public String sortString(String s) {
//
//		HashMap<Character, Integer> hm = new HashMap<>();
//		for (char c : s.toCharArray()) {
//			hm.put(c, hm.getOrDefault(c, 0) + 1);
//		}
//
//		StringBuilder sb = new StringBuilder();
//
//		List<Character> asc = new ArrayList<>(hm.keySet());
//		Collections.sort(asc);
//
//		while (!hm.isEmpty()) {
//
//			for (char c : asc) {
//				if (hm.containsKey(c)) {
//					sb.append(c);
//					hm.put(c, hm.get(c) - 1);
//					if (hm.get(c) == 0) {
//						hm.remove(c);
//					}
//				}
//			}
//
//			Collections.reverse(asc);
//			for (char c : asc) {
//				if (hm.containsKey(c)) {
//					sb.append(c);
//					hm.put(c, hm.get(c) - 1);
//					if (hm.get(c) == 0) {
//						hm.remove(c);
//					}
//				}
//			}
//
//			Collections.reverse(asc);
//		}
//
//		return sb.toString();
//	}
//}
