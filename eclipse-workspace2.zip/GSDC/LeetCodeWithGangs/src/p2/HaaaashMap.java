package p2;

import java.util.HashMap;
import java.util.Map;

public class HaaaashMap {
	public static void main(String[] args) {
		
		
		System.out.println('a' >= 'b' ? "a" : "b");

		
//
//		HashMap<Character, Integer> hm = new HashMap<>();
//
//		String s = "aaaaabbbbbbb";
//
//		for (int i = 0; i < s.length(); i++) {
//
//			char c = s.charAt(i);
//			hm.put(c, hm.getOrDefault(c, 0) + 1); 
//		}
//
//		for (Map.Entry<Character, Integer> entry : hm.entrySet()) {
//
//			System.out.println(entry.getKey() + ": " + entry.getValue());
//
//		}
	}

}
