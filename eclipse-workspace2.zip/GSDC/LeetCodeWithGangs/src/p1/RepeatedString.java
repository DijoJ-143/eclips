//package p1;
//
//import java.util.ArrayList;
//import java.util.HashSet;
//import java.util.List;
//import java.util.Set;
//
//class Solution {
//	public boolean repeatedSubstringPattern(String s) {
//
//		StringBuffer sb = new StringBuffer(s);
//		
//		sb.append(s.charAt(0));
//
//		for(int i =1;i<s.length();i++) {
//			
//			if(sb.substring(i, i)) {
//				
//			}
//		}
//			
//		}
//}
//
//public class RepeatedString {
//
//	public static void main(String[] args) {
//
//		Solution s = new Solution();
//		String str = "ababa";
//
//		System.out.println(s.repeatedSubstringPattern(str));
//	}
//}
