//package p1;
//
//import java.util.ArrayList;
//import java.util.Arrays;
//import java.util.Collection;
//import java.util.Collections;
//import java.util.HashMap;
//import java.util.List;
//import java.util.Map;
//
//class Solution {
//	public boolean hasGroupsSizeX(int[] deck) {
//		int count = 1;
//
//		Arrays.sort(deck);
//		
//		
//		
////		if(deck==null||deck.length=0) {
////			return false;
////		}
//
//		for (int i : deck) {
//			System.out.print(i);
//		}
//
//		HashMap<Integer, Integer> hmap = new HashMap<>();
//
//		for (int i = 1; i < deck.length; i++) {
//
//			if (deck[i] == deck[i - 1]) {
//				count++;
//			}
//
//			else {
//
//				hmap.put(deck[i - 1], count);
//				count = 1;
//			}
//
//			hmap.put(deck[deck.length - 1], count);
//
//		}
//
//		for (Map.Entry<Integer, Integer> entry : hmap.entrySet()) {
//			System.out.println("Key: " + entry.getKey() + ", Value: " + entry.getValue());
//		}
//		
//		
//		
//		
//		List<Integer> values= new ArrayList<>();
//		
//		
//		
//		for(int i: hmap.values()) {
//			values.add(i);
//			
//			
//			
//		}
//		
//		Collections.sort(values);
//		
//		System.out.println(values);
//		
//		for(int i=1;i< values.size();i++) {
//			
//			if(values.get(0)%values.get(i)!=0) {
//				return false;
//				
//			}
//			
//		}
//		
//
//		return true;
//	}
//}
//
//public class qyw {
//
//	public static void main(String[] args) {
//		Solution s = new Solution();
//		s.hasGroupsSizeX(new int[] { 1, 2, 3, 4, 4, 3, 2, 1,3});
//	}
//
//}
