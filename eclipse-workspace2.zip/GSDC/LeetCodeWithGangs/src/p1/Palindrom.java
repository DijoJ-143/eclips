//package p1;
//
//public class Palindrom {
//	public static void main(String[] args) {
//		int value = 10;
//		
//		
//		StringBuffer sb = new StringBuffer( Integer.toString(value));
//		
////		if(sb.isEmpty()|| sb.charAt(0)=='-')
//		System.out.println(sb.reverse());
//		
//		if(sb.equals(sb.reverse())){
//
//            System.out.println("palindrom");
//            }
//	}
//	
//
//}
