package Array3d;

import java.util.Scanner;

public class InternalExams {
	public static void main(String[] args) {

        // Creating a 3D array with 2 students, 2 exams, and 2 marks (internal and main)
        int[][][] data = new int[2][2][2];

        Scanner sc = new Scanner(System.in);

        while (true) {
            // User input for student number, exam code, and marks
            System.out.println("Enter student number (0 or 1)  or simply type 1122 to exit: ");
            int sno = sc.nextInt();
            
          if  (sno==1122) {
        	  System.out.println("Exiting from software.............");
        	  return;
          }
            

            System.out.println("Enter exam code (1: firstSem, 2: secondSem): ");
            int eno = sc.nextInt() - 1; // Subtracting 1 to make it 0-based indexing

           

            // Collecting marks for internal and main exams
            for (int i = 0; i < 2; i++) {
                System.out.println("Enter marks for " + (i == 0 ? "Internal Exam" : "Main Exam") + ": ");
                data[sno][eno][i] = sc.nextInt();
            }

            System.out.println("1. Continue marking\n2. Display data\n3. Exit");

            int choice = sc.nextInt();

            switch (choice) {
                case 1: {
                    // Continue marking (loop will continue)
                    break;
                }
                case 2: {
                    // Printing the stored data for each student and their exams
                    System.out.println("\nExam Data:");
                    int studentCounter = 1;
                    for (int[][] student : data) {
                        System.out.println("Student " + studentCounter++);
                        int examCounter = 1;
                        for (int[] examData : student) {
                            System.out.println("  Exam " + examCounter++);
                            System.out.println("    Internal: " + examData[0]);
                            System.out.println("    Main: " + examData[1]);
                        }
                    }
                    break;
                }
                case 3: {
                    // Exit the program
                    System.out.println("Exiting the program...");
                    sc.close();
                    return;
                }
                default: {
                    // Handle invalid choice
                    System.out.println("Invalid choice. Please try again.");
                    break;
                }
            }
        }
    }
}
