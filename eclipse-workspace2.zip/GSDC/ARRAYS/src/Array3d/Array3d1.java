package Array3d;

import java.util.Arrays;

public class Array3d1 {
	public static void main(String[] args) {
		
//		{
//			int a= 10;
//			System.out.println(a);
//		}
//		System.out.println(a);
		
		
		int[][][] data = { { { 1, 23 }, { 2, 43 } }, { { 3 }, { 4 } } };

		Arrays.stream(data).forEach(System.out::println);

		for (int d[][] : data) {
			for (int d1[] : d) {
				for (int d2 : d1) {
					System.out.println(d2);
				}

			}
		}
	}

}
