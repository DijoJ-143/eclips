package Exceptions;

public class NotInRange extends Exception {

	public NotInRange(String mesage) {
		super("its a custom exception message\n"+mesage);

	}

	@Override
	public String getMessage() {
		// TODO Auto-generated method stub
		return super.getMessage();
	}

}
