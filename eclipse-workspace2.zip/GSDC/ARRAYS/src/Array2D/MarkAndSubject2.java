package Array2D;

import java.util.Arrays;
import java.util.Scanner;

import Exceptions.NotInRange;

public class MarkAndSubject2 {
	public static void main(String[] args) throws NotInRange {
//		code for maths:101,english:202

		int[][] data = { { 101, 202 }, { 30, 44 }, { 40, 70 }, { 10, 30 } };
		
		
		
		
		/*
		 * reading 2 d array 
		 */
		
//		
//		int[] data1 = new int[5];
//		
//		
//		for(int a: data1) {
//			System.out.println(a);
//		}
		
		
		for(int data11[]:data) {
			for(int a: data11) {
				System.out.print(a + "\t");
				if(a%2==0) {
					System.out.print("an even number \t");
				}
			}
			System.out.println("\n");
			
		}
		
		
		
		
		
		
		
		
//		
//
//		int[] totalMark = Arrays.stream(data).skip(1).mapToInt(row -> Arrays.stream(row).sum()).toArray();
//		System.out.println("total mark   each students got  out of 300 :::" + Arrays.toString(totalMark));
//
//		Scanner sc = new Scanner(System.in);
//
//		System.out.println(
//				"Enter the number for subject u need to find the total mark \n 1 : \'MATH\' \n 2 : \'ENGLISH\'");
//		int choice = sc.nextInt();
//
//		switch ((choice-1)) {
//		case 0: {
//
//			findTotal(choice, data);
//			break;
//		}
//		case 1: {
//
//			findTotal(choice, data);
//			break;
//		}
//		default: {
//			throw new NotInRange("Unexpected value: " + choice);
//		}
//
//		}
//	}
//
//	public static void findTotal(int choice, int[][] data) {
//
//		System.out.println(Arrays.stream(data).skip(1).mapToInt(row -> (row[choice-1])).sum());

	}

}
