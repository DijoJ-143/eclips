package Array2D;

import java.util.Arrays;

public class MarkAndSubj {
	
	public static void main(String[] args) {
		int [][] data = {{10,20},{20,10},{10,20}};
		
		//English 1st , math 2nd , what to find sum of English
		
		int sum = Arrays.stream(data).mapToInt(row -> row[0]).sum();
		
		System.out.println("Student have total mark in english for 3 sem is "+sum  + " out of 150");
		
		
		int []defaultvalue = new int[5];
		System.out.println("\n default value "+ defaultvalue[3]);
		
	}

}
