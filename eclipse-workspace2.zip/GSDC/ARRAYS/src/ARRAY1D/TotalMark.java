package ARRAY1D;

import java.util.Arrays;

public class TotalMark {
	public static void main(String[] args) {
		int[] marks = { 1, 2, 3, 44 };

		int sum = Arrays.stream(marks).sum();
		System.out.print("total marks is " + sum);
	}

}
