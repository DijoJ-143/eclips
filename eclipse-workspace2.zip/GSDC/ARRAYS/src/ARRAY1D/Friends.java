package ARRAY1D;

import java.util.Arrays;
import java.util.Iterator;
import java.util.Scanner;
import java.util.stream.Stream;

public class Friends {
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		
		System.out.println("Enter the number of friends");
		int len= sc.nextInt() ;
		
		 String  []names= new String[len];
		
		for(int i =0;i<len;i++) {
			System.out.println("Friend : "+(i+1)+" name");
			names[i]=sc.next();
		}
		
		
		Arrays.stream(names).forEach(System.out::println);
		
		sc.close();
		
	
		
		
	}
	

}
