package Functions;

public class f1 {
	
	public static int add(int x, int y) {
		return x+y;
	}
	
	public static void main(String[] args) {
		
		int result = add(10,10);
		System.out.println(result);
	}
	
	


}
