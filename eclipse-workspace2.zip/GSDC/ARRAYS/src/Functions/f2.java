package Functions;

public class f2 {
	
	public static void display(int b) {
		System.out.println(b);
	}

	public static void (int m, int n ) {
		display();
		
	}
	
	public static void main(String[] args) {
		
	}
}
